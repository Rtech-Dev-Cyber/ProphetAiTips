'use client'

import { ReactNode } from 'react'
import { Home, Heart, Zap, ShoppingCart, SlidersHorizontal } from 'lucide-react'

interface PhoneFrameProps {
  children: ReactNode
  activeTab: string
  onTabChange: (tab: string) => void
}

const TABS = [
  { id: 'home', icon: Home, label: 'Home' },
  { id: 'vip', icon: Heart, label: 'VIP' },
  { id: 'ai', icon: Zap, label: 'AI' },
  { id: 'history', icon: ShoppingCart, label: 'History' },
  { id: 'settings', icon: SlidersHorizontal, label: 'Profile' },
]

export function PhoneFrame({ children, activeTab, onTabChange }: PhoneFrameProps) {
  return (
    <div className="relative mx-auto" style={{ width: 375, height: 780 }}>
      {/* Outer shell */}
      <div className="absolute inset-0 rounded-[44px] border-[8px] border-[oklch(0.22_0_0)] bg-[oklch(0.1_0_0)] shadow-2xl overflow-hidden">
        {/* Status bar */}
        <div className="flex items-center justify-between px-6 pt-3 pb-1 bg-[oklch(0.1_0_0)]">
          <span className="text-[11px] font-semibold text-foreground">8:41</span>
          <div className="w-24 h-6 rounded-full bg-[oklch(0.08_0_0)] absolute top-3 left-1/2 -translate-x-1/2" />
          <div className="flex items-center gap-1">
            <div className="w-4 h-2.5 rounded-sm border border-foreground/50 relative">
              <div className="absolute inset-0.5 right-0.5 bg-foreground/70 rounded-sm" />
            </div>
          </div>
        </div>

        {/* Screen content area */}
        <div className="flex flex-col" style={{ height: 'calc(100% - 40px)' }}>
          {/* Scrollable content */}
          <div className="flex-1 overflow-y-auto phone-scroll bg-[oklch(0.1_0_0)]">
            {children}
          </div>

          {/* Bottom nav bar */}
          <div className="flex-shrink-0 border-t border-border bg-[oklch(0.12_0_0)]">
            <div className="flex items-center justify-around py-2 px-2">
              {TABS.map((tab) => {
                const Icon = tab.icon
                const isActive = activeTab === tab.id
                const isCenter = tab.id === 'ai'
                return (
                  <button
                    key={tab.id}
                    onClick={() => onTabChange(tab.id)}
                    className={`flex flex-col items-center gap-0.5 transition-all ${
                      isCenter ? '-mt-4' : ''
                    }`}
                    aria-label={tab.label}
                  >
                    {isCenter ? (
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-all ${
                        isActive
                          ? 'bg-[oklch(0.55_0.22_293)] purple-glow'
                          : 'bg-[oklch(0.55_0.22_293)]'
                      }`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                    ) : (
                      <div className={`flex flex-col items-center gap-0.5 px-2 py-1 rounded-lg transition-all ${
                        isActive ? 'text-[oklch(0.55_0.22_293)]' : 'text-muted-foreground'
                      }`}>
                        <Icon className="w-5 h-5" />
                        <span className="text-[9px] font-medium">{tab.label}</span>
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
            {/* Home indicator */}
            <div className="flex justify-center pb-2">
              <div className="w-28 h-1 rounded-full bg-foreground/20" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
