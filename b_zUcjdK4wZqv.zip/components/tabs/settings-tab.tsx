'use client'

import { useState } from 'react'
import {
  User, Moon, Bell, Lock, LogOut, FileText, Shield, Users,
  Crown, ChevronRight, Zap, ShoppingCart, MessageCircle,
} from 'lucide-react'
import { CREDIT_PACKAGES } from '@/lib/types'

export function SettingsTab() {
  const [darkMode, setDarkMode] = useState(true)
  const [notifications, setNotifications] = useState(true)
  const [showCredits, setShowCredits] = useState(false)

  const stats = [
    { label: 'Teams', value: 9, icon: Users, color: 'text-[oklch(0.55_0.22_293)]' },
    { label: 'Matches', value: 0, icon: Zap, color: 'text-muted-foreground' },
    { label: 'Leagues', value: 128, icon: Crown, color: 'text-[oklch(0.72_0.17_75)]' },
  ]

  const accountItems = [
    { label: 'Personal Information', sub: 'Edit your profile information', icon: User },
    { label: 'Password', sub: 'Change your password', icon: Lock },
  ]

  const aboutItems = [
    { label: 'Terms of Use (EULA)', sub: 'View terms of use', icon: FileText },
    { label: 'Privacy Policy', sub: 'View privacy policy', icon: Shield },
    { label: 'User Information Text', sub: 'View user and membership agreement', icon: Users },
  ]

  const handleCreditPurchase = (pkg: typeof CREDIT_PACKAGES[0]) => {
    const msg = encodeURIComponent(
      `Hi! I'd like to buy ${pkg.credits} AI Credits for $${pkg.price} on PitchProphet.`
    )
    window.open(`https://t.me/pitchprophet?text=${msg}`, '_blank')
  }

  return (
    <div className="px-3 pb-4">
      {/* Profile header */}
      <div className="flex items-center gap-3 py-4 border-b border-border mb-4">
        <div className="w-14 h-14 rounded-full bg-[oklch(0.3_0.12_293/0.4)] border border-[oklch(0.55_0.22_293)] flex items-center justify-center">
          <User className="w-7 h-7 text-[oklch(0.55_0.22_293)]" />
        </div>
        <div>
          <p className="font-bold text-sm text-foreground">User Account</p>
          <p className="text-[10px] text-muted-foreground">user@email.com</p>
          <div className="flex items-center gap-1.5 mt-1">
            <Zap className="w-3 h-3 text-[oklch(0.55_0.22_293)]" />
            <span className="text-[10px] text-[oklch(0.55_0.22_293)] font-semibold">10 AI Credits</span>
          </div>
        </div>
        <button className="ml-auto flex items-center gap-1 bg-[oklch(0.72_0.17_75)] text-[oklch(0.1_0_0)] text-[9px] font-black px-2.5 py-1 rounded-full">
          <Crown className="w-3 h-3" />
          UPGRADE
        </button>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {stats.map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-card rounded-xl border border-border p-2.5 text-center">
              <Icon className={`w-4 h-4 mx-auto mb-1 ${s.color}`} />
              <p className={`text-base font-black ${s.color}`}>{s.value}</p>
              <p className="text-[9px] text-muted-foreground">{s.label}</p>
            </div>
          )
        })}
      </div>

      {/* Buy Credits button */}
      <button
        onClick={() => setShowCredits(!showCredits)}
        className="w-full flex items-center justify-between bg-card border border-[oklch(0.55_0.22_293/0.4)] rounded-xl px-4 py-3 mb-4 transition-all"
      >
        <div className="flex items-center gap-2">
          <ShoppingCart className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
          <div className="text-left">
            <p className="text-xs font-bold text-foreground">Buy AI Credits</p>
            <p className="text-[10px] text-muted-foreground">Power your AI analysis</p>
          </div>
        </div>
        <ChevronRight className={`w-4 h-4 text-muted-foreground transition-transform ${showCredits ? 'rotate-90' : ''}`} />
      </button>

      {showCredits && (
        <div className="mb-4 flex flex-col gap-2 slide-up">
          {CREDIT_PACKAGES.map((pkg) => (
            <div
              key={pkg.credits}
              className={`flex items-center justify-between bg-card rounded-xl border p-3 ${
                pkg.badge ? 'border-[oklch(0.72_0.17_75/0.5)] vip-glow' : 'border-border'
              }`}
            >
              <div>
                {pkg.badge && (
                  <span className="text-[8px] font-black text-[oklch(0.72_0.17_75)] bg-[oklch(0.28_0.08_75/0.3)] px-1.5 py-0.5 rounded-full mb-1 inline-block">
                    {pkg.badge}
                  </span>
                )}
                <p className="text-sm font-bold text-foreground">{pkg.credits} Credits</p>
                <p className="text-[10px] text-muted-foreground">{pkg.label} pack</p>
              </div>
              <button
                onClick={() => handleCreditPurchase(pkg)}
                className="flex items-center gap-1.5 bg-[oklch(0.55_0.22_293)] text-white text-xs font-bold px-3 py-1.5 rounded-lg"
              >
                <MessageCircle className="w-3 h-3" />
                ${pkg.price}
              </button>
            </div>
          ))}
          <p className="text-[9px] text-muted-foreground text-center">
            Pay via Telegram / PayPal / Bank Transfer
          </p>
        </div>
      )}

      {/* Preferences */}
      <SectionHeader label="Preferences" />
      <div className="bg-card rounded-xl border border-border overflow-hidden mb-4">
        <ToggleRow
          icon={Moon}
          label="Dark Mode"
          sub="Use dark theme"
          checked={darkMode}
          onChange={setDarkMode}
        />
        <div className="border-t border-border" />
        <NavRow icon={User} label="Language" sub="Device Default" />
      </div>

      {/* Notifications */}
      <SectionHeader label="Notifications" />
      <div className="bg-card rounded-xl border border-border overflow-hidden mb-4">
        <ToggleRow
          icon={Bell}
          label="Push Notifications"
          sub="Enabled"
          checked={notifications}
          onChange={setNotifications}
        />
      </div>

      {/* Account */}
      <SectionHeader label="Account" />
      <div className="bg-card rounded-xl border border-border overflow-hidden mb-4">
        {accountItems.map((item, i) => (
          <div key={item.label}>
            {i > 0 && <div className="border-t border-border" />}
            <NavRow icon={item.icon} label={item.label} sub={item.sub} />
          </div>
        ))}
        <div className="border-t border-border" />
        <button className="w-full flex items-center gap-3 px-4 py-3">
          <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center">
            <LogOut className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-left">
            <p className="text-xs font-semibold text-red-400">Logout</p>
            <p className="text-[10px] text-muted-foreground">Sign out of your account</p>
          </div>
        </button>
      </div>

      {/* About */}
      <SectionHeader label="About" />
      <div className="bg-card rounded-xl border border-border overflow-hidden mb-4">
        {aboutItems.map((item, i) => (
          <div key={item.label}>
            {i > 0 && <div className="border-t border-border" />}
            <NavRow icon={item.icon} label={item.label} sub={item.sub} />
          </div>
        ))}
        <div className="border-t border-border" />
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
              <MessageCircle className="w-4 h-4 text-green-400" />
            </div>
            <div>
              <p className="text-xs font-semibold text-foreground">Customer Support</p>
              <p className="text-[10px] text-muted-foreground">Get priority support service</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-black text-[oklch(0.72_0.17_75)] bg-[oklch(0.28_0.08_75/0.3)] px-2 py-0.5 rounded-full flex items-center gap-1">
              <Crown className="w-2.5 h-2.5" /> PREMIUM
            </span>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </div>
        </div>
      </div>
    </div>
  )
}

function SectionHeader({ label }: { label: string }) {
  return (
    <p className="text-xs font-bold text-foreground mb-2 px-1">{label}</p>
  )
}

function NavRow({ icon: Icon, label, sub }: { icon: React.ComponentType<{ className?: string }>, label: string, sub: string }) {
  return (
    <button className="w-full flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
          <Icon className="w-4 h-4 text-muted-foreground" />
        </div>
        <div className="text-left">
          <p className="text-xs font-semibold text-foreground">{label}</p>
          <p className="text-[10px] text-muted-foreground">{sub}</p>
        </div>
      </div>
      <ChevronRight className="w-4 h-4 text-muted-foreground" />
    </button>
  )
}

function ToggleRow({
  icon: Icon, label, sub, checked, onChange
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  sub: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
          <Icon className="w-4 h-4 text-muted-foreground" />
        </div>
        <div>
          <p className="text-xs font-semibold text-foreground">{label}</p>
          <p className="text-[10px] text-muted-foreground">{sub}</p>
        </div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-11 h-6 rounded-full transition-colors ${
          checked ? 'bg-[oklch(0.55_0.22_293)]' : 'bg-secondary border border-border'
        }`}
      >
        <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all ${
          checked ? 'left-[calc(100%-1.375rem)]' : 'left-0.5'
        }`} />
      </button>
    </div>
  )
}
