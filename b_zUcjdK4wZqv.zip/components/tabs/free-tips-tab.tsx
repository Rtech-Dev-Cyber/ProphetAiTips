'use client'

import { TipCard } from '@/components/tip-card'
import { MOCK_FREE_TIPS } from '@/lib/types'
import { Zap, TrendingUp, Target, BarChart3 } from 'lucide-react'
import { format } from 'date-fns'

export function FreeTipsTab() {
  const stats = [
    { label: 'Win Rate', value: '72%', icon: TrendingUp, color: 'text-green-400' },
    { label: "Today's Tips", value: '8', icon: Target, color: 'text-[oklch(0.55_0.22_293)]' },
    { label: 'Avg Odds', value: '1.85', icon: BarChart3, color: 'text-[oklch(0.72_0.17_75)]' },
  ]

  return (
    <div className="px-3 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between py-3">
        <div>
          <h1 className="text-lg font-bold text-foreground text-balance">PitchProphet</h1>
          <p className="text-[11px] text-muted-foreground">
            {format(new Date(), 'EEEE, dd MMM yyyy')}
          </p>
        </div>
        <div className="flex items-center gap-1.5 bg-[oklch(0.55_0.22_293)] px-2.5 py-1 rounded-full">
          <Zap className="w-3 h-3 text-white" />
          <span className="text-[11px] font-bold text-white">FREE</span>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2 mb-4">
        {stats.map((s) => {
          const Icon = s.icon
          return (
            <div key={s.label} className="bg-card rounded-xl p-2.5 border border-border text-center">
              <Icon className={`w-4 h-4 mx-auto mb-1 ${s.color}`} />
              <p className={`text-base font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[9px] text-muted-foreground">{s.label}</p>
            </div>
          )
        })}
      </div>

      {/* Section header */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-bold text-foreground">Today&apos;s Predictions</h2>
        <span className="text-[10px] text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">
          {MOCK_FREE_TIPS.length} tips
        </span>
      </div>

      {/* Tips */}
      <div className="flex flex-col gap-2.5">
        {MOCK_FREE_TIPS.map((tip, i) => (
          <div key={tip.id} className="slide-up" style={{ animationDelay: `${i * 60}ms` }}>
            <TipCard tip={tip} />
          </div>
        ))}
      </div>

      {/* Upgrade banner */}
      <div className="mt-4 rounded-xl border border-[oklch(0.72_0.17_75/0.4)] bg-[oklch(0.14_0_0)] p-4 text-center vip-glow">
        <p className="text-xs font-bold text-[oklch(0.72_0.17_75)] mb-1">UNLOCK VIP TIPS</p>
        <p className="text-[10px] text-muted-foreground mb-2">
          Get Correct Score, HT/FT, Odds 5+ and more
        </p>
        <button className="bg-[oklch(0.72_0.17_75)] text-[oklch(0.1_0_0)] text-xs font-bold px-4 py-1.5 rounded-full">
          View Plans
        </button>
      </div>
    </div>
  )
}
