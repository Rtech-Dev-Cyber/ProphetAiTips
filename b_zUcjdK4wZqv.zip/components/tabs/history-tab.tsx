'use client'

import { MOCK_FREE_TIPS, MOCK_VIP_TIPS } from '@/lib/types'
import { CheckCircle2, XCircle, Clock, BarChart3, TrendingUp } from 'lucide-react'
import { format } from 'date-fns'

export function HistoryTab() {
  const allTips = [
    ...MOCK_FREE_TIPS,
    ...Object.values(MOCK_VIP_TIPS).flat(),
  ].filter((t) => t.status === 'finished')

  const won = allTips.filter((t) => t.result === 'won').length
  const lost = allTips.filter((t) => t.result === 'lost').length
  const total = allTips.length
  const winRate = total > 0 ? Math.round((won / total) * 100) : 0

  return (
    <div className="px-3 pb-4">
      {/* Header */}
      <div className="flex items-center gap-2 py-3">
        <BarChart3 className="w-5 h-5 text-[oklch(0.55_0.22_293)]" />
        <h1 className="text-lg font-bold text-foreground">History</h1>
      </div>

      {/* Stats overview */}
      <div className="bg-card rounded-xl border border-border p-4 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-green-400" />
          <span className="text-sm font-bold text-foreground">Overall Performance</span>
        </div>
        <div className="grid grid-cols-3 gap-3 text-center">
          <div>
            <p className="text-xl font-black text-green-400">{won}</p>
            <p className="text-[9px] text-muted-foreground uppercase">Won</p>
          </div>
          <div>
            <p className="text-xl font-black text-red-400">{lost}</p>
            <p className="text-[9px] text-muted-foreground uppercase">Lost</p>
          </div>
          <div>
            <p className="text-xl font-black text-[oklch(0.55_0.22_293)]">{winRate}%</p>
            <p className="text-[9px] text-muted-foreground uppercase">Win Rate</p>
          </div>
        </div>
        {/* Win rate bar */}
        <div className="mt-3">
          <div className="h-2 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full rounded-full bg-green-500 transition-all duration-700"
              style={{ width: `${winRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* Past tips list */}
      <h2 className="text-sm font-bold text-foreground mb-2">Recent Results</h2>
      <div className="flex flex-col gap-2">
        {allTips.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-center gap-2">
            <Clock className="w-8 h-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">No finished tips yet</p>
          </div>
        ) : (
          allTips.map((tip) => (
            <div
              key={tip.id}
              className={`flex items-center justify-between bg-card rounded-xl border p-3 ${
                tip.result === 'won' ? 'border-green-500/30' : 'border-red-500/30'
              }`}
            >
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-muted-foreground">
                  {tip.league?.name} &bull; {format(new Date(tip.match_date), 'dd MMM')}
                </p>
                <p className="text-xs font-semibold text-foreground truncate">
                  {tip.home_team} vs {tip.away_team}
                </p>
                <p className="text-[10px] text-[oklch(0.55_0.22_293)]">{tip.prediction}</p>
              </div>
              <div className="flex flex-col items-end gap-1 ml-2">
                <div className={`text-base font-black ${
                  tip.result === 'won' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {tip.home_score} - {tip.away_score}
                </div>
                {tip.result === 'won'
                  ? <CheckCircle2 className="w-4 h-4 text-green-400" />
                  : <XCircle className="w-4 h-4 text-red-400" />
                }
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
