'use client'

import { useState } from 'react'
import { Zap, Bot, Calendar, Flag, Calculator, Minus, Plus, Shuffle } from 'lucide-react'
import { MOCK_FREE_TIPS, CouponSelection } from '@/lib/types'
import { format, addDays } from 'date-fns'

type BetType = '1x2' | 'over_under' | 'btts' | 'double_chance'

const BET_TYPE_OPTIONS: { id: BetType; icon: string; label: string }[] = [
  { id: '1x2', icon: '1X2', label: 'Match Winner' },
  { id: 'over_under', icon: '2.5', label: 'Over/Under 2.5' },
  { id: 'btts', icon: '0|1', label: 'Both Teams to Score' },
  { id: 'double_chance', icon: 'x2', label: 'Double Chance' },
]

const LEAGUES = ['Premier League', 'La Liga', 'Bundesliga', 'Serie A', 'Ligue 1', 'Champions League']

type TabMode = 'coupon' | 'ask'

export function AiTab() {
  const [mode, setMode] = useState<TabMode>('coupon')

  // Coupon builder state
  const [selectedDates, setSelectedDates] = useState<string[]>(['today'])
  const [selectedLeague, setSelectedLeague] = useState<string>('')
  const [selectedBetTypes, setSelectedBetTypes] = useState<BetType[]>(['1x2', 'over_under'])
  const [matchCount, setMatchCount] = useState(3)
  const [generatedCoupon, setGeneratedCoupon] = useState<CouponSelection[] | null>(null)
  const [loading, setLoading] = useState(false)

  // Ask AI state
  const [question, setQuestion] = useState('')
  const [aiResponse, setAiResponse] = useState<string | null>(null)
  const [aiLoading, setAiLoading] = useState(false)

  const dates = [
    { id: 'today', label: 'Today', date: format(new Date(), 'MM/dd') },
    { id: 'tomorrow', label: 'Tomorrow', date: format(addDays(new Date(), 1), 'MM/dd') },
    { id: 'dayafter', label: 'Day After', date: format(addDays(new Date(), 2), 'MM/dd') },
  ]

  const toggleDate = (id: string) => {
    setSelectedDates((prev) =>
      prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]
    )
  }

  const toggleBetType = (id: BetType) => {
    setSelectedBetTypes((prev) =>
      prev.includes(id) ? prev.filter((b) => b !== id) : [...prev, id]
    )
  }

  const generateCoupon = async () => {
    setLoading(true)
    setGeneratedCoupon(null)
    await new Promise((r) => setTimeout(r, 1400))
    // Build a mock coupon from available tips
    const pool = MOCK_FREE_TIPS.slice(0, matchCount).map((t) => ({
      home_team: t.home_team,
      away_team: t.away_team,
      match_date: t.match_date,
      prediction: t.prediction,
      tip_type: t.tip_type,
      odds: t.odds ?? 1.5,
      league: t.league?.name ?? 'Unknown',
    }))
    setGeneratedCoupon(pool)
    setLoading(false)
  }

  const totalOdds = generatedCoupon
    ? generatedCoupon.reduce((acc, s) => acc * s.odds, 1).toFixed(2)
    : null

  const handleAsk = async () => {
    if (!question.trim()) return
    setAiLoading(true)
    setAiResponse(null)
    await new Promise((r) => setTimeout(r, 1800))
    setAiResponse(
      `Based on recent form and head-to-head statistics, here is my analysis:\n\nFor your question about "${question}", the data suggests that the likely outcome involves strong home advantage combined with both teams' recent scoring form. Key factors: last 5 H2H meetings, current league position, and injury news from the official team sheets.\n\nPrediction confidence: 76% • Recommended odds range: 1.7–2.1`
    )
    setAiLoading(false)
  }

  return (
    <div className="px-3 pb-4">
      {/* Header */}
      <div className="flex items-center gap-2 py-3">
        <Zap className="w-5 h-5 text-[oklch(0.55_0.22_293)]" />
        <h1 className="text-lg font-bold text-foreground">AI Centre</h1>
      </div>

      {/* Mode toggle */}
      <div className="flex rounded-xl overflow-hidden border border-border mb-4">
        <button
          onClick={() => setMode('coupon')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold transition-all ${
            mode === 'coupon'
              ? 'bg-[oklch(0.55_0.22_293)] text-white'
              : 'bg-secondary text-muted-foreground'
          }`}
        >
          <Shuffle className="w-3.5 h-3.5" />
          Smart Coupon
        </button>
        <button
          onClick={() => setMode('ask')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold transition-all ${
            mode === 'ask'
              ? 'bg-[oklch(0.55_0.22_293)] text-white'
              : 'bg-secondary text-muted-foreground'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          Ask AI
        </button>
      </div>

      {mode === 'coupon' ? (
        <>
          {/* Date Selection */}
          <div className="bg-card rounded-xl border border-border p-3 mb-3">
            <div className="flex items-center gap-2 mb-2.5">
              <Calendar className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
              <span className="text-sm font-bold text-foreground">Date Selection</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-2">Select days for predictions</p>
            <div className="flex flex-col gap-1.5">
              {dates.map((d) => (
                <button
                  key={d.id}
                  onClick={() => toggleDate(d.id)}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg border transition-all ${
                    selectedDates.includes(d.id)
                      ? 'border-[oklch(0.55_0.22_293)] bg-[oklch(0.3_0.12_293/0.2)]'
                      : 'border-border bg-secondary'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs font-semibold text-foreground">{d.label}</span>
                  </div>
                  <span className={`text-xs font-bold ${
                    selectedDates.includes(d.id) ? 'text-[oklch(0.55_0.22_293)]' : 'text-muted-foreground'
                  }`}>{d.date}</span>
                </button>
              ))}
            </div>
          </div>

          {/* League Selection */}
          <div className="bg-card rounded-xl border border-border p-3 mb-3">
            <div className="flex items-center gap-2 mb-2.5">
              <Flag className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
              <span className="text-sm font-bold text-foreground">League Selection</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-2">Select leagues you want predictions for</p>
            <select
              value={selectedLeague}
              onChange={(e) => setSelectedLeague(e.target.value)}
              className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-xs text-foreground appearance-none"
            >
              <option value="">Select league</option>
              {LEAGUES.map((l) => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>

          {/* Bet Types */}
          <div className="bg-card rounded-xl border border-border p-3 mb-3">
            <div className="flex items-center gap-2 mb-2.5">
              <Calculator className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
              <span className="text-sm font-bold text-foreground">Bet Types</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-2">
              Which bet types would you like predictions for?
            </p>
            <div className="grid grid-cols-4 gap-1.5">
              {BET_TYPE_OPTIONS.map((bt) => (
                <button
                  key={bt.id}
                  onClick={() => toggleBetType(bt.id)}
                  className={`flex flex-col items-center gap-1 p-2 rounded-xl border transition-all ${
                    selectedBetTypes.includes(bt.id)
                      ? 'border-[oklch(0.55_0.22_293)] bg-[oklch(0.3_0.12_293/0.3)]'
                      : 'border-border bg-secondary'
                  }`}
                >
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black ${
                    selectedBetTypes.includes(bt.id)
                      ? 'bg-[oklch(0.55_0.22_293)] text-white'
                      : 'bg-[oklch(0.22_0_0)] text-muted-foreground'
                  }`}>
                    {bt.icon}
                  </span>
                  <span className="text-[8px] text-center leading-tight text-muted-foreground">
                    {bt.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Match Count */}
          <div className="bg-card rounded-xl border border-border p-3 mb-4">
            <div className="flex items-center gap-2 mb-1">
              <Shuffle className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
              <span className="text-sm font-bold text-foreground">Select Number of Matches</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-3">How many matches per coupon? (2–6)</p>
            <div className="flex items-center justify-center gap-6">
              <button
                onClick={() => setMatchCount((c) => Math.max(2, c - 1))}
                className="w-9 h-9 rounded-full border border-[oklch(0.55_0.22_293)] flex items-center justify-center text-[oklch(0.55_0.22_293)] transition-all active:scale-90"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-2xl font-black text-foreground w-6 text-center">{matchCount}</span>
              <button
                onClick={() => setMatchCount((c) => Math.min(6, c + 1))}
                className="w-9 h-9 rounded-full border border-[oklch(0.55_0.22_293)] flex items-center justify-center text-[oklch(0.55_0.22_293)] transition-all active:scale-90"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Create Coupon CTA */}
          <button
            onClick={generateCoupon}
            disabled={loading || selectedDates.length === 0 || selectedBetTypes.length === 0}
            className="w-full flex items-center justify-center gap-2 bg-[oklch(0.55_0.22_293)] text-white font-bold py-3.5 rounded-xl text-sm purple-glow transition-all disabled:opacity-60 active:scale-95"
          >
            <Zap className="w-4 h-4" />
            {loading ? 'Building Coupon...' : 'Create Coupon'}
          </button>

          {/* Generated coupon result */}
          {generatedCoupon && (
            <div className="mt-4 bg-card rounded-xl border border-[oklch(0.55_0.22_293/0.5)] p-3 slide-up">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-bold text-foreground">Your Coupon</span>
                <span className="text-sm font-black text-[oklch(0.72_0.17_75)]">
                  Total Odds: {totalOdds}x
                </span>
              </div>
              <div className="flex flex-col gap-2">
                {generatedCoupon.map((sel, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div>
                      <p className="text-[10px] text-muted-foreground">{sel.league}</p>
                      <p className="text-xs font-semibold text-foreground">
                        {sel.home_team} vs {sel.away_team}
                      </p>
                      <p className="text-[10px] text-[oklch(0.55_0.22_293)]">{sel.prediction}</p>
                    </div>
                    <span className="text-xs font-bold text-[oklch(0.72_0.17_75)]">
                      @{sel.odds.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : (
        /* Ask AI mode */
        <div>
          <div className="bg-card rounded-xl border border-border p-4 mb-3">
            <div className="flex items-center gap-2 mb-3">
              <Bot className="w-5 h-5 text-[oklch(0.55_0.22_293)]" />
              <span className="text-sm font-bold text-foreground">Ask AI Analyst</span>
            </div>
            <p className="text-[10px] text-muted-foreground mb-3">
              Ask anything about upcoming matches, team form, or predictions.
            </p>
            <textarea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="e.g. Who will win Arsenal vs Chelsea this weekend?"
              className="w-full bg-secondary border border-border rounded-xl px-3 py-2.5 text-xs text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:border-[oklch(0.55_0.22_293)]"
              rows={3}
            />
            <button
              onClick={handleAsk}
              disabled={aiLoading || !question.trim()}
              className="mt-2.5 w-full flex items-center justify-center gap-2 bg-[oklch(0.55_0.22_293)] text-white font-bold py-2.5 rounded-xl text-xs purple-glow disabled:opacity-60 active:scale-95 transition-all"
            >
              <Zap className="w-3.5 h-3.5" />
              {aiLoading ? 'Analysing...' : 'Get AI Analysis'}
            </button>
          </div>

          {aiResponse && (
            <div className="bg-card rounded-xl border border-[oklch(0.55_0.22_293/0.4)] p-4 slide-up">
              <div className="flex items-center gap-2 mb-2">
                <Bot className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
                <span className="text-xs font-bold text-[oklch(0.55_0.22_293)]">AI Analysis</span>
              </div>
              <p className="text-xs text-foreground leading-relaxed whitespace-pre-line">{aiResponse}</p>
              <div className="mt-2.5 flex items-center gap-1.5">
                <Zap className="w-3 h-3 text-muted-foreground" />
                <span className="text-[9px] text-muted-foreground">1 credit used &bull; 9 remaining</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
