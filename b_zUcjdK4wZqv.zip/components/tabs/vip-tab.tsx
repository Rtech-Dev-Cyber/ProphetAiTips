'use client'

import { useState } from 'react'
import { TipCard } from '@/components/tip-card'
import { VIP_TIER_LABELS, VIP_TIER_PRICES, MOCK_VIP_TIPS, VipTier, VipPlan } from '@/lib/types'
import { Crown, Lock, MessageCircle } from 'lucide-react'

const TIERS: VipTier[] = ['odds2', 'correct_score', 'ht_ft', 'odds5', 'super_combo', 'over_under', 'all_access']

const TIER_ICONS: Record<VipTier, string> = {
  odds2: '2',
  correct_score: 'CS',
  ht_ft: 'HT',
  odds5: '5',
  super_combo: 'SC',
  over_under: 'OU',
  all_access: '★',
}

const PLANS: { id: VipPlan; label: string }[] = [
  { id: 'weekly', label: 'Weekly' },
  { id: 'monthly', label: 'Monthly' },
  { id: 'quarterly', label: '3 Months' },
]

export function VipTab() {
  const [activeTier, setActiveTier] = useState<VipTier>('odds2')
  const [activePlan, setActivePlan] = useState<VipPlan>('monthly')
  const [showPricing, setShowPricing] = useState(false)

  const tips = MOCK_VIP_TIPS[activeTier]
  const price = VIP_TIER_PRICES[activeTier][activePlan]

  const handleSubscribe = () => {
    const msg = encodeURIComponent(
      `Hi! I'd like to subscribe to PitchProphet VIP - ${VIP_TIER_LABELS[activeTier]} (${activePlan} plan - $${price})`
    )
    window.open(`https://t.me/pitchprophet?text=${msg}`, '_blank')
  }

  return (
    <div className="px-3 pb-4">
      {/* Header */}
      <div className="flex items-center gap-2 py-3">
        <Crown className="w-5 h-5 text-[oklch(0.72_0.17_75)]" />
        <h1 className="text-lg font-bold text-foreground">VIP Tips</h1>
      </div>

      {/* Tier selector */}
      <div className="overflow-x-auto pb-2 -mx-3 px-3 phone-scroll">
        <div className="flex gap-2 w-max">
          {TIERS.map((tier) => (
            <button
              key={tier}
              onClick={() => setActiveTier(tier)}
              className={`flex-shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl border transition-all ${
                activeTier === tier
                  ? 'border-[oklch(0.72_0.17_75)] bg-[oklch(0.28_0.08_75/0.3)]'
                  : 'border-border bg-card'
              }`}
            >
              <span className={`text-base font-black ${
                activeTier === tier ? 'text-[oklch(0.72_0.17_75)]' : 'text-muted-foreground'
              }`}>
                {TIER_ICONS[tier]}
              </span>
              <span className={`text-[9px] font-semibold whitespace-nowrap ${
                activeTier === tier ? 'text-[oklch(0.72_0.17_75)]' : 'text-muted-foreground'
              }`}>
                {VIP_TIER_LABELS[tier]}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Tips or locked state */}
      <div className="mt-3 mb-3">
        {tips.length > 0 ? (
          <div className="flex flex-col gap-2.5">
            {tips.map((tip) => (
              <TipCard key={tip.id} tip={tip} locked={true} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 gap-2">
            <Lock className="w-8 h-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground text-center">
              Subscribe to see {VIP_TIER_LABELS[activeTier]} tips
            </p>
          </div>
        )}
      </div>

      {/* Pricing card */}
      <div className="rounded-xl border border-[oklch(0.72_0.17_75/0.5)] bg-[oklch(0.14_0_0)] p-4 vip-glow">
        <div className="flex items-center gap-2 mb-3">
          <Crown className="w-4 h-4 text-[oklch(0.72_0.17_75)]" />
          <span className="text-sm font-bold text-[oklch(0.72_0.17_75)]">
            {VIP_TIER_LABELS[activeTier]}
          </span>
        </div>

        {/* Plan selector */}
        <div className="flex gap-1.5 mb-4">
          {PLANS.map((plan) => (
            <button
              key={plan.id}
              onClick={() => setActivePlan(plan.id)}
              className={`flex-1 text-[10px] font-semibold py-1.5 rounded-lg border transition-all ${
                activePlan === plan.id
                  ? 'border-[oklch(0.55_0.22_293)] bg-[oklch(0.3_0.12_293/0.3)] text-[oklch(0.55_0.22_293)]'
                  : 'border-border bg-secondary text-muted-foreground'
              }`}
            >
              {plan.label}
            </button>
          ))}
        </div>

        {/* Price display */}
        <div className="text-center mb-4">
          <span className="text-3xl font-black text-foreground">${price}</span>
          <span className="text-xs text-muted-foreground ml-1">/ {activePlan === 'quarterly' ? '3 months' : activePlan}</span>
        </div>

        {/* Subscribe button */}
        <button
          onClick={handleSubscribe}
          className="w-full flex items-center justify-center gap-2 bg-[oklch(0.55_0.22_293)] text-white font-bold py-3 rounded-xl text-sm purple-glow transition-all active:scale-95"
        >
          <MessageCircle className="w-4 h-4" />
          Subscribe via Telegram
        </button>
        <p className="text-center text-[9px] text-muted-foreground mt-2">
          Also available on WhatsApp &bull; Pay via PayPal or bank transfer
        </p>
      </div>
    </div>
  )
}
