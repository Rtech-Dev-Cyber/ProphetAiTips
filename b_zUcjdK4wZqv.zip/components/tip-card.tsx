'use client'

import { Prediction } from '@/lib/types'
import { format } from 'date-fns'
import { CheckCircle2, XCircle, Clock, Zap, Lock } from 'lucide-react'

interface TipCardProps {
  tip: Prediction
  locked?: boolean
}

const TIP_TYPE_LABEL: Record<string, string> = {
  '1x2': '1X2',
  over_under: 'O/U',
  btts: 'BTTS',
  double_chance: 'DC',
  correct_score: 'CS',
  ht_ft: 'HT/FT',
}

export function TipCard({ tip, locked = false }: TipCardProps) {
  const isWon = tip.result === 'won'
  const isLost = tip.result === 'lost'
  const isLive = tip.status === 'live'
  const isPending = tip.result === 'pending' && tip.status !== 'live'

  return (
    <div
      className={`relative rounded-xl border p-3 transition-all ${
        tip.is_vip
          ? 'border-[oklch(0.72_0.17_75/0.4)] bg-[oklch(0.14_0_0)]'
          : 'border-border bg-card'
      } ${locked ? 'opacity-80' : ''}`}
    >
      {/* League + date row */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          {isLive && (
            <span className="flex items-center gap-1 text-[10px] font-bold text-red-400 bg-red-400/10 px-1.5 py-0.5 rounded-full">
              <span className="live-dot w-1.5 h-1.5 rounded-full bg-red-400 inline-block" />
              LIVE
            </span>
          )}
          <span className="text-[10px] text-muted-foreground uppercase tracking-wide">
            {tip.league?.name ?? 'Unknown League'}
          </span>
        </div>
        <span className="text-[10px] text-muted-foreground">
          {format(new Date(tip.match_date), 'dd MMM, HH:mm')}
        </span>
      </div>

      {/* Teams */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex-1">
          <p className="font-semibold text-sm text-foreground leading-tight">
            {tip.home_team}
          </p>
          <p className="text-[10px] text-muted-foreground mt-0.5">vs</p>
          <p className="font-semibold text-sm text-foreground leading-tight">
            {tip.away_team}
          </p>
        </div>

        {/* Score / lock / status */}
        <div className="text-right">
          {locked ? (
            <div className="flex flex-col items-center gap-1">
              <Lock className="w-5 h-5 text-[oklch(0.72_0.17_75)]" />
              <span className="text-[9px] text-[oklch(0.72_0.17_75)] font-semibold">VIP</span>
            </div>
          ) : tip.status === 'finished' && tip.home_score !== null ? (
            <div className={`text-lg font-bold ${isWon ? 'text-green-400' : isLost ? 'text-red-400' : 'text-foreground'}`}>
              {tip.home_score} - {tip.away_score}
            </div>
          ) : isLive ? (
            <div className="text-sm font-bold text-red-400">
              {tip.home_score ?? 0} - {tip.away_score ?? 0}
            </div>
          ) : null}
        </div>
      </div>

      {/* Prediction row */}
      {locked ? (
        <div className="flex items-center justify-between bg-[oklch(0.18_0_0)] rounded-lg px-3 py-2">
          <span className="text-xs text-muted-foreground italic">Subscribe to unlock prediction</span>
          <Lock className="w-3.5 h-3.5 text-muted-foreground" />
        </div>
      ) : (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-[oklch(0.55_0.22_293)] bg-[oklch(0.3_0.12_293/0.4)] px-1.5 py-0.5 rounded-md uppercase">
              {TIP_TYPE_LABEL[tip.tip_type] ?? tip.tip_type}
            </span>
            <span className="text-xs font-semibold text-foreground">{tip.prediction}</span>
          </div>
          <div className="flex items-center gap-2">
            {tip.odds && (
              <span className="text-xs font-bold text-[oklch(0.72_0.17_75)]">
                @{tip.odds.toFixed(2)}
              </span>
            )}
            {isWon && <CheckCircle2 className="w-4 h-4 text-green-400" />}
            {isLost && <XCircle className="w-4 h-4 text-red-400" />}
            {isPending && <Clock className="w-4 h-4 text-muted-foreground" />}
            {isLive && <Zap className="w-4 h-4 text-yellow-400" />}
          </div>
        </div>
      )}

      {/* Confidence bar */}
      {!locked && (
        <div className="mt-2.5">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[9px] text-muted-foreground uppercase tracking-wide">Confidence</span>
            <span className="text-[9px] font-bold text-[oklch(0.55_0.22_293)]">{tip.confidence}%</span>
          </div>
          <div className="h-1 rounded-full bg-secondary overflow-hidden">
            <div
              className="h-full rounded-full bg-[oklch(0.55_0.22_293)] transition-all duration-700"
              style={{ width: `${tip.confidence}%` }}
            />
          </div>
        </div>
      )}
    </div>
  )
}
