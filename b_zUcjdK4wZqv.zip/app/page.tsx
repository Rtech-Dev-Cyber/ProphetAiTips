import Link from 'next/link'
import {
  Zap, Crown, Bot, BarChart3, Shield, Target,
  TrendingUp, CheckCircle2, MessageCircle, Star,
} from 'lucide-react'

export default function LandingPage() {
  const features = [
    {
      icon: Zap,
      title: 'Daily Free Tips',
      desc: 'Get AI-generated football predictions every day — completely free. 1X2, BTTS, Over/Under and more.',
      color: 'text-[oklch(0.55_0.22_293)]',
      bg: 'bg-[oklch(0.3_0.12_293/0.2)]',
    },
    {
      icon: Crown,
      title: 'VIP Premium Tips',
      desc: 'Unlock Correct Score, HT/FT, Odds 5+, Super Combo and All-Access plans. Researched by AI, curated by experts.',
      color: 'text-[oklch(0.72_0.17_75)]',
      bg: 'bg-[oklch(0.28_0.08_75/0.2)]',
    },
    {
      icon: Bot,
      title: 'Ask AI Analyst',
      desc: 'Ask any football question — team form, H2H stats, injury updates — and get instant AI analysis.',
      color: 'text-green-400',
      bg: 'bg-green-400/10',
    },
    {
      icon: Target,
      title: 'Smart Coupon Builder',
      desc: 'Select your preferred bet types, dates, and leagues. Let AI build the perfect coupon for you.',
      color: 'text-[oklch(0.55_0.22_293)]',
      bg: 'bg-[oklch(0.3_0.12_293/0.2)]',
    },
    {
      icon: BarChart3,
      title: 'Performance History',
      desc: 'Full transparency. View all past predictions with results, win rates, and detailed statistics.',
      color: 'text-[oklch(0.72_0.17_75)]',
      bg: 'bg-[oklch(0.28_0.08_75/0.2)]',
    },
    {
      icon: Shield,
      title: '128 Leagues Covered',
      desc: 'From the Premier League to Turkish Super Lig. We cover 128+ football leagues worldwide.',
      color: 'text-green-400',
      bg: 'bg-green-400/10',
    },
  ]

  const stats = [
    { value: '72%', label: 'Win Rate', icon: TrendingUp },
    { value: '128+', label: 'Leagues', icon: Star },
    { value: '10K+', label: 'Tips Given', icon: Target },
    { value: '5K+', label: 'Happy Users', icon: CheckCircle2 },
  ]

  const vipTiers = [
    { name: 'Odds 2 Picks', weekly: 5, monthly: 15 },
    { name: 'Correct Score', weekly: 8, monthly: 22 },
    { name: 'HT/FT', weekly: 8, monthly: 22 },
    { name: 'Odds 5+', weekly: 10, monthly: 28 },
    { name: 'Super Combo', weekly: 10, monthly: 28 },
    { name: 'Over/Under', weekly: 5, monthly: 15 },
    { name: 'All Access', weekly: 20, monthly: 55, highlight: true },
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 border-b border-border bg-[oklch(0.1_0_0/0.95)] backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[oklch(0.55_0.22_293)] flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="font-black text-lg text-foreground tracking-tight">PitchProphet</span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/preview"
              className="text-sm text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
            >
              App Preview
            </Link>
            <Link
              href="/auth/login"
              className="text-sm font-semibold text-foreground border border-border px-4 py-1.5 rounded-lg hover:border-[oklch(0.55_0.22_293)] transition-all"
            >
              Sign In
            </Link>
            <Link
              href="/auth/sign-up"
              className="text-sm font-bold bg-[oklch(0.55_0.22_293)] text-white px-4 py-1.5 rounded-lg purple-glow hover:bg-[oklch(0.5_0.22_293)] transition-all"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden py-20 sm:py-28 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-[oklch(0.3_0.12_293/0.3)] border border-[oklch(0.55_0.22_293/0.4)] rounded-full px-4 py-1.5 mb-6">
            <div className="live-dot w-2 h-2 rounded-full bg-green-400" />
            <span className="text-xs font-semibold text-[oklch(0.55_0.22_293)]">AI-Powered Football Predictions</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-black text-foreground mb-6 leading-tight text-balance">
            Beat the Odds with{' '}
            <span className="text-[oklch(0.55_0.22_293)]">AI Football</span>
            {' '}Intelligence
          </h1>

          <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed text-pretty">
            Daily free tips, VIP predictions, and a smart coupon builder — all powered by advanced AI analysis across 128+ football leagues worldwide.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/preview"
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-[oklch(0.55_0.22_293)] text-white font-bold px-8 py-3.5 rounded-xl text-base purple-glow hover:bg-[oklch(0.5_0.22_293)] transition-all"
            >
              <Zap className="w-5 h-5" />
              Try App Preview
            </Link>
            <Link
              href="/auth/sign-up"
              className="w-full sm:w-auto flex items-center justify-center gap-2 border border-border text-foreground font-semibold px-8 py-3.5 rounded-xl text-base hover:border-[oklch(0.55_0.22_293)] transition-all"
            >
              <Crown className="w-5 h-5 text-[oklch(0.72_0.17_75)]" />
              Join Free
            </Link>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="border-y border-border py-8 px-4">
        <div className="max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-6">
          {stats.map((s) => {
            const Icon = s.icon
            return (
              <div key={s.label} className="text-center">
                <Icon className="w-5 h-5 mx-auto mb-2 text-[oklch(0.55_0.22_293)]" />
                <p className="text-2xl font-black text-foreground">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            )
          })}
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4 text-balance">
              Everything You Need to Win
            </h2>
            <p className="text-muted-foreground text-base max-w-xl mx-auto text-pretty">
              A complete AI-powered football prediction platform built for serious punters.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f) => {
              const Icon = f.icon
              return (
                <div
                  key={f.title}
                  className="bg-card border border-border rounded-2xl p-6 hover:border-[oklch(0.55_0.22_293/0.5)] transition-all"
                >
                  <div className={`w-12 h-12 rounded-xl ${f.bg} flex items-center justify-center mb-4`}>
                    <Icon className={`w-6 h-6 ${f.color}`} />
                  </div>
                  <h3 className="font-bold text-base text-foreground mb-2">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* VIP Pricing */}
      <section className="py-20 px-4 border-t border-border">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-[oklch(0.28_0.08_75/0.2)] border border-[oklch(0.72_0.17_75/0.4)] rounded-full px-4 py-1.5 mb-4">
              <Crown className="w-4 h-4 text-[oklch(0.72_0.17_75)]" />
              <span className="text-xs font-bold text-[oklch(0.72_0.17_75)]">VIP SUBSCRIPTIONS</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4 text-balance">
              Choose Your VIP Plan
            </h2>
            <p className="text-muted-foreground text-sm max-w-md mx-auto text-pretty">
              Subscribe via Telegram or WhatsApp. Pay by PayPal or bank transfer. Instant activation.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {vipTiers.map((tier) => (
              <div
                key={tier.name}
                className={`rounded-2xl border p-5 ${
                  tier.highlight
                    ? 'border-[oklch(0.72_0.17_75/0.6)] bg-[oklch(0.14_0_0)] vip-glow'
                    : 'border-border bg-card'
                }`}
              >
                {tier.highlight && (
                  <div className="flex items-center gap-1 mb-3">
                    <span className="text-[10px] font-black text-[oklch(0.72_0.17_75)] bg-[oklch(0.28_0.08_75/0.3)] px-2 py-0.5 rounded-full">
                      BEST VALUE
                    </span>
                  </div>
                )}
                <h3 className="font-bold text-sm text-foreground mb-3">{tier.name}</h3>
                <div className="flex items-end gap-1 mb-1">
                  <span className="text-2xl font-black text-foreground">${tier.weekly}</span>
                  <span className="text-xs text-muted-foreground pb-0.5">/ week</span>
                </div>
                <p className="text-xs text-muted-foreground mb-4">${tier.monthly} / month</p>
                <a
                  href={`https://t.me/pitchprophet?text=${encodeURIComponent(`Hi! I'd like VIP - ${tier.name}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    tier.highlight
                      ? 'bg-[oklch(0.72_0.17_75)] text-[oklch(0.1_0_0)]'
                      : 'bg-[oklch(0.55_0.22_293)] text-white'
                  }`}
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  Subscribe Now
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 border-t border-border">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-black text-foreground mb-4 text-balance">
            Start Winning Today
          </h2>
          <p className="text-muted-foreground text-base mb-8 text-pretty">
            Join thousands of users getting daily AI football tips. Free to start, VIP when you&apos;re ready.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/preview"
              className="flex items-center justify-center gap-2 bg-[oklch(0.55_0.22_293)] text-white font-bold px-8 py-3.5 rounded-xl purple-glow hover:bg-[oklch(0.5_0.22_293)] transition-all"
            >
              <Zap className="w-5 h-5" />
              Explore the App
            </Link>
            <a
              href="https://t.me/pitchprophet"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 border border-border text-foreground font-semibold px-8 py-3.5 rounded-xl hover:border-[oklch(0.55_0.22_293)] transition-all"
            >
              <MessageCircle className="w-5 h-5" />
              Contact on Telegram
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[oklch(0.55_0.22_293)] flex items-center justify-center">
              <Zap className="w-3 h-3 text-white" />
            </div>
            <span className="font-black text-sm text-foreground">PitchProphet</span>
          </div>
          <p className="text-xs text-muted-foreground text-center">
            For entertainment purposes only. Please gamble responsibly.
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <Link href="/preview" className="hover:text-foreground transition-colors">App Preview</Link>
            <Link href="/admin" className="hover:text-foreground transition-colors">Admin</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
