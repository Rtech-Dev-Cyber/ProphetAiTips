'use client'

import { useState } from 'react'
import {
  Crown, Zap, Users, ShieldCheck, Plus, Search,
  CheckCircle2, XCircle, Loader2, ChevronDown,
} from 'lucide-react'
import { VIP_TIER_LABELS, VipTier, VipPlan, CREDIT_PACKAGES } from '@/lib/types'
import Link from 'next/link'

type AdminView = 'vip' | 'credits' | 'users'

const TIERS: VipTier[] = ['odds2', 'correct_score', 'ht_ft', 'odds5', 'super_combo', 'over_under', 'all_access']
const PLANS: { id: VipPlan; label: string; days: number }[] = [
  { id: 'weekly', label: '1 Week', days: 7 },
  { id: 'monthly', label: '1 Month', days: 30 },
  { id: 'quarterly', label: '3 Months', days: 90 },
]

// Mock recent grants for demo
const MOCK_GRANTS = [
  { email: 'john@example.com', tier: 'odds2', plan: 'monthly', expires: '2026-06-02', credits: null },
  { email: 'sara@email.com', tier: 'all_access', plan: 'weekly', expires: '2026-05-09', credits: null },
  { email: 'mike@gmail.com', tier: null, plan: null, expires: null, credits: 30 },
  { email: 'ana@hotmail.com', tier: 'correct_score', plan: 'quarterly', expires: '2026-08-02', credits: null },
]

export default function AdminPage() {
  const [password, setPassword] = useState('')
  const [authenticated, setAuthenticated] = useState(false)
  const [authError, setAuthError] = useState(false)
  const [view, setView] = useState<AdminView>('vip')

  // VIP grant form
  const [vipEmail, setVipEmail] = useState('')
  const [vipTier, setVipTier] = useState<VipTier>('odds2')
  const [vipPlan, setVipPlan] = useState<VipPlan>('monthly')
  const [vipNotes, setVipNotes] = useState('')
  const [vipLoading, setVipLoading] = useState(false)
  const [vipResult, setVipResult] = useState<{ ok: boolean; msg: string } | null>(null)

  // Credits form
  const [creditEmail, setCreditEmail] = useState('')
  const [creditAmount, setCreditAmount] = useState(10)
  const [creditReason, setCreditReason] = useState('')
  const [creditLoading, setCreditLoading] = useState(false)
  const [creditResult, setCreditResult] = useState<{ ok: boolean; msg: string } | null>(null)

  // User search
  const [searchEmail, setSearchEmail] = useState('')

  const handleAuth = () => {
    if (password === process.env.NEXT_PUBLIC_ADMIN_PASSWORD || password === 'admin123') {
      setAuthenticated(true)
      setAuthError(false)
    } else {
      setAuthError(true)
    }
  }

  const handleGrantVip = async () => {
    if (!vipEmail.trim()) return
    setVipLoading(true)
    setVipResult(null)
    try {
      const res = await fetch('/api/admin/grant-vip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: vipEmail, tier: vipTier, plan: vipPlan, notes: vipNotes }),
      })
      const data = await res.json()
      if (res.ok) {
        setVipResult({ ok: true, msg: `VIP granted to ${vipEmail} — ${VIP_TIER_LABELS[vipTier]} (${vipPlan})` })
        setVipEmail('')
        setVipNotes('')
      } else {
        setVipResult({ ok: false, msg: data.error ?? 'Failed to grant VIP' })
      }
    } catch {
      setVipResult({ ok: false, msg: 'Network error. Please try again.' })
    } finally {
      setVipLoading(false)
    }
  }

  const handleGrantCredits = async () => {
    if (!creditEmail.trim() || creditAmount <= 0) return
    setCreditLoading(true)
    setCreditResult(null)
    try {
      const res = await fetch('/api/admin/grant-credits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: creditEmail, amount: creditAmount, reason: creditReason }),
      })
      const data = await res.json()
      if (res.ok) {
        setCreditResult({ ok: true, msg: `${creditAmount} credits added to ${creditEmail}` })
        setCreditEmail('')
        setCreditReason('')
      } else {
        setCreditResult({ ok: false, msg: data.error ?? 'Failed to grant credits' })
      }
    } catch {
      setCreditResult({ ok: false, msg: 'Network error. Please try again.' })
    } finally {
      setCreditLoading(false)
    }
  }

  // Auth gate
  if (!authenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-[oklch(0.3_0.12_293/0.3)] border border-[oklch(0.55_0.22_293)] flex items-center justify-center mx-auto mb-4">
              <ShieldCheck className="w-7 h-7 text-[oklch(0.55_0.22_293)]" />
            </div>
            <h1 className="text-2xl font-black text-foreground">Admin Panel</h1>
            <p className="text-sm text-muted-foreground mt-1">PitchProphet Management</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-6">
            <label className="block text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">
              Admin Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAuth()}
              placeholder="Enter admin password"
              className={`w-full bg-secondary border rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors ${
                authError ? 'border-red-500' : 'border-border'
              }`}
            />
            {authError && (
              <p className="text-xs text-red-400 mt-1.5 flex items-center gap-1">
                <XCircle className="w-3 h-3" /> Incorrect password
              </p>
            )}
            <button
              onClick={handleAuth}
              className="mt-4 w-full bg-[oklch(0.55_0.22_293)] text-white font-bold py-3 rounded-xl purple-glow hover:bg-[oklch(0.5_0.22_293)] transition-all"
            >
              Access Admin Panel
            </button>
          </div>
          <p className="text-center text-xs text-muted-foreground mt-4">
            <Link href="/" className="hover:text-foreground transition-colors">← Back to site</Link>
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Admin nav */}
      <header className="border-b border-border bg-[oklch(0.12_0_0)] sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-[oklch(0.55_0.22_293)] flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-black text-foreground">PitchProphet</span>
            <span className="text-[10px] font-bold text-muted-foreground bg-secondary px-2 py-0.5 rounded-full uppercase">Admin</span>
          </div>
          <Link href="/" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
            ← Site
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Summary cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Users', value: '1,247', icon: Users, color: 'text-[oklch(0.55_0.22_293)]' },
            { label: 'Active VIPs', value: '84', icon: Crown, color: 'text-[oklch(0.72_0.17_75)]' },
            { label: "Today's Tips", value: '12', icon: Zap, color: 'text-green-400' },
            { label: 'Credits Sold', value: '3,410', icon: ShieldCheck, color: 'text-blue-400' },
          ].map((s) => {
            const Icon = s.icon
            return (
              <div key={s.label} className="bg-card border border-border rounded-2xl p-4">
                <Icon className={`w-5 h-5 mb-2 ${s.color}`} />
                <p className={`text-2xl font-black ${s.color}`}>{s.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
              </div>
            )
          })}
        </div>

        {/* View tabs */}
        <div className="flex gap-2 mb-6 border-b border-border pb-4">
          {(['vip', 'credits', 'users'] as AdminView[]).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all capitalize ${
                view === v
                  ? 'bg-[oklch(0.55_0.22_293)] text-white'
                  : 'text-muted-foreground hover:text-foreground bg-secondary'
              }`}
            >
              {v === 'vip' ? 'Grant VIP' : v === 'credits' ? 'Grant Credits' : 'Users'}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Form panel */}
          <div className="lg:col-span-3">
            {view === 'vip' && (
              <div className="bg-card border border-border rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Crown className="w-5 h-5 text-[oklch(0.72_0.17_75)]" />
                  <h2 className="font-bold text-foreground">Grant VIP Subscription</h2>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      User Email
                    </label>
                    <input
                      type="email"
                      value={vipEmail}
                      onChange={(e) => setVipEmail(e.target.value)}
                      placeholder="user@example.com"
                      className="w-full bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      VIP Tier
                    </label>
                    <div className="relative">
                      <select
                        value={vipTier}
                        onChange={(e) => setVipTier(e.target.value as VipTier)}
                        className="w-full bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground appearance-none focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors"
                      >
                        {TIERS.map((t) => (
                          <option key={t} value={t}>{VIP_TIER_LABELS[t]}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      Plan Duration
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {PLANS.map((p) => (
                        <button
                          key={p.id}
                          onClick={() => setVipPlan(p.id)}
                          className={`py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                            vipPlan === p.id
                              ? 'border-[oklch(0.55_0.22_293)] bg-[oklch(0.3_0.12_293/0.3)] text-[oklch(0.55_0.22_293)]'
                              : 'border-border bg-secondary text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      Notes (optional)
                    </label>
                    <input
                      type="text"
                      value={vipNotes}
                      onChange={(e) => setVipNotes(e.target.value)}
                      placeholder="e.g. Paid via PayPal on 2 May"
                      className="w-full bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors"
                    />
                  </div>

                  {/* Summary */}
                  <div className="bg-secondary rounded-xl p-3 text-xs text-muted-foreground">
                    Will grant: <span className="text-foreground font-semibold">{VIP_TIER_LABELS[vipTier]}</span> for{' '}
                    <span className="text-foreground font-semibold">
                      {PLANS.find((p) => p.id === vipPlan)?.days} days
                    </span>
                    {' '}to <span className="text-[oklch(0.55_0.22_293)] font-semibold">{vipEmail || 'user email'}</span>
                  </div>

                  <button
                    onClick={handleGrantVip}
                    disabled={vipLoading || !vipEmail.trim()}
                    className="w-full flex items-center justify-center gap-2 bg-[oklch(0.72_0.17_75)] text-[oklch(0.1_0_0)] font-bold py-3 rounded-xl text-sm vip-glow disabled:opacity-60 hover:bg-[oklch(0.68_0.17_75)] transition-all"
                  >
                    {vipLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                    {vipLoading ? 'Granting...' : 'Grant VIP Access'}
                  </button>

                  {vipResult && (
                    <div className={`flex items-start gap-2 p-3 rounded-xl text-xs ${
                      vipResult.ok
                        ? 'bg-green-500/10 border border-green-500/30 text-green-400'
                        : 'bg-red-500/10 border border-red-500/30 text-red-400'
                    }`}>
                      {vipResult.ok ? <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" /> : <XCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />}
                      {vipResult.msg}
                    </div>
                  )}
                </div>
              </div>
            )}

            {view === 'credits' && (
              <div className="bg-card border border-border rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Zap className="w-5 h-5 text-[oklch(0.55_0.22_293)]" />
                  <h2 className="font-bold text-foreground">Grant AI Credits</h2>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      User Email
                    </label>
                    <input
                      type="email"
                      value={creditEmail}
                      onChange={(e) => setCreditEmail(e.target.value)}
                      placeholder="user@example.com"
                      className="w-full bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      Credit Package
                    </label>
                    <div className="grid grid-cols-3 gap-2 mb-3">
                      {CREDIT_PACKAGES.map((pkg) => (
                        <button
                          key={pkg.credits}
                          onClick={() => setCreditAmount(pkg.credits)}
                          className={`py-3 rounded-xl text-xs font-semibold border transition-all ${
                            creditAmount === pkg.credits
                              ? 'border-[oklch(0.55_0.22_293)] bg-[oklch(0.3_0.12_293/0.3)] text-[oklch(0.55_0.22_293)]'
                              : 'border-border bg-secondary text-muted-foreground hover:text-foreground'
                          }`}
                        >
                          <div className="font-black text-sm">{pkg.credits}</div>
                          <div className="text-[9px]">credits</div>
                          {pkg.badge && <div className="text-[8px] text-[oklch(0.72_0.17_75)]">{pkg.badge}</div>}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">Custom amount:</span>
                      <input
                        type="number"
                        value={creditAmount}
                        onChange={(e) => setCreditAmount(Number(e.target.value))}
                        min={1}
                        className="w-24 bg-secondary border border-border rounded-lg px-3 py-1.5 text-sm text-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">
                      Reason (optional)
                    </label>
                    <input
                      type="text"
                      value={creditReason}
                      onChange={(e) => setCreditReason(e.target.value)}
                      placeholder="e.g. Paid $5 via PayPal"
                      className="w-full bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors"
                    />
                  </div>

                  <button
                    onClick={handleGrantCredits}
                    disabled={creditLoading || !creditEmail.trim() || creditAmount <= 0}
                    className="w-full flex items-center justify-center gap-2 bg-[oklch(0.55_0.22_293)] text-white font-bold py-3 rounded-xl text-sm purple-glow disabled:opacity-60 hover:bg-[oklch(0.5_0.22_293)] transition-all"
                  >
                    {creditLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                    {creditLoading ? 'Adding...' : `Add ${creditAmount} Credits`}
                  </button>

                  {creditResult && (
                    <div className={`flex items-start gap-2 p-3 rounded-xl text-xs ${
                      creditResult.ok
                        ? 'bg-green-500/10 border border-green-500/30 text-green-400'
                        : 'bg-red-500/10 border border-red-500/30 text-red-400'
                    }`}>
                      {creditResult.ok ? <CheckCircle2 className="w-4 h-4 flex-shrink-0" /> : <XCircle className="w-4 h-4 flex-shrink-0" />}
                      {creditResult.msg}
                    </div>
                  )}
                </div>
              </div>
            )}

            {view === 'users' && (
              <div className="bg-card border border-border rounded-2xl p-6">
                <div className="flex items-center gap-2 mb-6">
                  <Search className="w-5 h-5 text-muted-foreground" />
                  <h2 className="font-bold text-foreground">User Lookup</h2>
                </div>
                <div className="flex gap-2 mb-4">
                  <input
                    type="email"
                    value={searchEmail}
                    onChange={(e) => setSearchEmail(e.target.value)}
                    placeholder="Search by email..."
                    className="flex-1 bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[oklch(0.55_0.22_293)] transition-colors"
                  />
                  <button className="bg-[oklch(0.55_0.22_293)] text-white px-4 py-2.5 rounded-xl text-sm font-semibold">
                    Search
                  </button>
                </div>
                <p className="text-xs text-muted-foreground text-center py-4">
                  Connect your Supabase database to search users.
                </p>
              </div>
            )}
          </div>

          {/* Recent activity panel */}
          <div className="lg:col-span-2">
            <div className="bg-card border border-border rounded-2xl p-5">
              <h3 className="font-bold text-sm text-foreground mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {MOCK_GRANTS.map((g, i) => (
                  <div key={i} className="flex items-start gap-3 py-2 border-b border-border last:border-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      g.credits ? 'bg-[oklch(0.3_0.12_293/0.3)]' : 'bg-[oklch(0.28_0.08_75/0.2)]'
                    }`}>
                      {g.credits ? (
                        <Zap className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
                      ) : (
                        <Crown className="w-4 h-4 text-[oklch(0.72_0.17_75)]" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-foreground truncate">{g.email}</p>
                      {g.tier ? (
                        <p className="text-[10px] text-muted-foreground">
                          {VIP_TIER_LABELS[g.tier as VipTier]} · {g.plan}
                        </p>
                      ) : (
                        <p className="text-[10px] text-muted-foreground">{g.credits} credits added</p>
                      )}
                      {g.expires && (
                        <p className="text-[9px] text-green-400">Expires {g.expires}</p>
                      )}
                    </div>
                    <CheckCircle2 className="w-3.5 h-3.5 text-green-400 flex-shrink-0 mt-0.5" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
