import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const { email, amount, reason } = await req.json()

    if (!email || !amount || Number(amount) <= 0) {
      return NextResponse.json({ error: 'email and a positive amount are required' }, { status: 400 })
    }

    const supabase = await createClient()

    // Verify caller is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
    }

    const { data: adminProfile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!adminProfile?.is_admin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Find the target user
    const { data: targetProfile } = await supabase
      .from('profiles')
      .select('id, ai_credits')
      .eq('email', email)
      .single()

    if (!targetProfile) {
      return NextResponse.json({ error: `No user found with email: ${email}` }, { status: 404 })
    }

    const numAmount = Number(amount)
    const newCredits = (targetProfile.ai_credits ?? 0) + numAmount

    // Update credits on profile
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ ai_credits: newCredits })
      .eq('id', targetProfile.id)

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 500 })
    }

    // Log the credit grant
    await supabase.from('ai_credits_log').insert({
      user_id: targetProfile.id,
      amount: numAmount,
      reason: reason ?? 'Admin grant',
      granted_by: user.id,
    })

    return NextResponse.json({
      success: true,
      message: `${numAmount} credits added to ${email}. New balance: ${newCredits}`,
    })
  } catch {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
