import { createClient } from '@/lib/supabase/server'
import { NextRequest, NextResponse } from 'next/server'
import { VipPlan } from '@/lib/types'

const PLAN_DAYS: Record<VipPlan, number> = {
  weekly: 7,
  monthly: 30,
  quarterly: 90,
}

export async function POST(req: NextRequest) {
  try {
    const { email, tier, plan, notes } = await req.json()

    if (!email || !tier || !plan) {
      return NextResponse.json({ error: 'email, tier and plan are required' }, { status: 400 })
    }

    const supabase = await createClient()

    // Verify caller is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
    }

    const { data: adminProfile } = await supabase
      .from('profiles')
      .select('is_admin')
      .eq('id', user.id)
      .single()

    if (!adminProfile?.is_admin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    // Find the target user by email
    const { data: targetProfile } = await supabase
      .from('profiles')
      .select('id')
      .eq('email', email)
      .single()

    if (!targetProfile) {
      return NextResponse.json({ error: `No user found with email: ${email}` }, { status: 404 })
    }

    const days = PLAN_DAYS[plan as VipPlan]
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + days)

    const { error } = await supabase.from('vip_subscriptions').insert({
      user_id: targetProfile.id,
      tier,
      plan,
      expires_at: expiresAt.toISOString(),
      granted_by: user.id,
      notes: notes ?? null,
    })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: `VIP ${tier} (${plan}) granted to ${email}. Expires: ${expiresAt.toDateString()}`,
    })
  } catch (e) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
