import type { Metadata, Viewport } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'PitchProphet — AI Football Predictions',
  description: 'AI-powered football tips, VIP predictions, and smart coupon builder. Get daily predictions for 128+ leagues.',
  keywords: ['football tips', 'soccer predictions', 'AI betting tips', 'VIP football tips', 'smart coupon'],
  authors: [{ name: 'PitchProphet' }],
  creator: 'PitchProphet',
  openGraph: {
    title: 'PitchProphet — AI Football Predictions',
    description: 'AI-powered football tips and VIP predictions for 128+ leagues.',
    type: 'website',
  },
  icons: {
    icon: '/favicon.ico',
  },
}

export const viewport: Viewport = {
  themeColor: '#0D0D0D',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} bg-background`}>
      <body className="font-sans antialiased min-h-screen bg-background text-foreground">
        {children}
      </body>
    </html>
  )
}
