'use client'

import { useState } from 'react'
import { PhoneFrame } from '@/components/phone-frame'
import { FreeTipsTab } from '@/components/tabs/free-tips-tab'
import { VipTab } from '@/components/tabs/vip-tab'
import { AiTab } from '@/components/tabs/ai-tab'
import { HistoryTab } from '@/components/tabs/history-tab'
import { SettingsTab } from '@/components/tabs/settings-tab'
import Link from 'next/link'
import { ArrowLeft, Smartphone } from 'lucide-react'

type Tab = 'home' | 'vip' | 'ai' | 'history' | 'settings'

const TAB_LABELS: Record<Tab, string> = {
  home: 'Free Tips',
  vip: 'VIP Tips',
  ai: 'AI Centre',
  history: 'History',
  settings: 'Profile & Settings',
}

export default function PreviewPage() {
  const [activeTab, setActiveTab] = useState<Tab>('home')

  const renderTab = () => {
    switch (activeTab) {
      case 'home': return <FreeTipsTab />
      case 'vip': return <VipTab />
      case 'ai': return <AiTab />
      case 'history': return <HistoryTab />
      case 'settings': return <SettingsTab />
    }
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top bar */}
      <header className="border-b border-border bg-[oklch(0.12_0_0)]">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-[oklch(0.55_0.22_293)]" />
            <span className="text-sm font-bold text-foreground">App Preview</span>
          </div>
          <div className="text-xs text-muted-foreground hidden sm:block">
            Interactive demo — no account required
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Left: Tab info panel */}
        <div className="lg:w-72 xl:w-80 border-b lg:border-b-0 lg:border-r border-border p-6 bg-[oklch(0.12_0_0)]">
          <h1 className="text-xl font-black text-foreground mb-1">PitchProphet</h1>
          <p className="text-sm text-muted-foreground mb-6">AI Football Predictions</p>

          <div className="space-y-1">
            {(Object.keys(TAB_LABELS) as Tab[]).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === tab
                    ? 'bg-[oklch(0.3_0.12_293/0.3)] text-[oklch(0.55_0.22_293)] border border-[oklch(0.55_0.22_293/0.4)]'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                {TAB_LABELS[tab]}
              </button>
            ))}
          </div>

          <div className="mt-8 p-4 bg-card border border-border rounded-xl">
            <p className="text-xs font-bold text-foreground mb-2">Currently viewing:</p>
            <p className="text-sm text-[oklch(0.55_0.22_293)] font-semibold">{TAB_LABELS[activeTab]}</p>
            <p className="text-[10px] text-muted-foreground mt-2 leading-relaxed">
              Click the bottom navigation in the phone to switch tabs, or use the sidebar buttons above.
            </p>
          </div>

          <div className="mt-4 p-4 bg-[oklch(0.28_0.08_75/0.15)] border border-[oklch(0.72_0.17_75/0.3)] rounded-xl">
            <p className="text-[10px] font-bold text-[oklch(0.72_0.17_75)] mb-1">GET THE APP</p>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              This is a web preview. The full Flutter mobile app is available for Android.
            </p>
          </div>
        </div>

        {/* Right: Phone frame */}
        <div className="flex-1 flex items-center justify-center p-8 lg:p-12">
          <div className="flex flex-col items-center gap-6">
            <PhoneFrame activeTab={activeTab} onTabChange={(t) => setActiveTab(t as Tab)}>
              {renderTab()}
            </PhoneFrame>
            <p className="text-xs text-muted-foreground">
              Swipe through tabs using the navigation bar inside the phone
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
