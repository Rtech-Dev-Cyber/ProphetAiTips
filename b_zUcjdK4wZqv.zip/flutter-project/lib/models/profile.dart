class UserProfile {
  final String id;
  final String? email;
  final String? fullName;
  final String? avatarUrl;
  final bool isAdmin;
  final int aiCredits;
  final DateTime createdAt;

  const UserProfile({
    required this.id,
    this.email,
    this.fullName,
    this.avatarUrl,
    this.isAdmin = false,
    this.aiCredits = 10,
    required this.createdAt,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['id'] as String,
      email: json['email'] as String?,
      fullName: json['full_name'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      isAdmin: json['is_admin'] as bool? ?? false,
      aiCredits: json['ai_credits'] as int? ?? 10,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }

  UserProfile copyWith({int? aiCredits, String? fullName, String? avatarUrl}) {
    return UserProfile(
      id: id,
      email: email,
      fullName: fullName ?? this.fullName,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      isAdmin: isAdmin,
      aiCredits: aiCredits ?? this.aiCredits,
      createdAt: createdAt,
    );
  }
}

class VipSubscription {
  final String id;
  final String userId;
  final String tier;
  final String plan;
  final DateTime startsAt;
  final DateTime expiresAt;
  final String? notes;

  const VipSubscription({
    required this.id,
    required this.userId,
    required this.tier,
    required this.plan,
    required this.startsAt,
    required this.expiresAt,
    this.notes,
  });

  bool get isActive => expiresAt.isAfter(DateTime.now());

  factory VipSubscription.fromJson(Map<String, dynamic> json) {
    return VipSubscription(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      tier: json['tier'] as String,
      plan: json['plan'] as String,
      startsAt: DateTime.parse(json['started_at'] as String),
      expiresAt: DateTime.parse(json['expires_at'] as String),
      notes: json['notes'] as String?,
    );
  }
}
