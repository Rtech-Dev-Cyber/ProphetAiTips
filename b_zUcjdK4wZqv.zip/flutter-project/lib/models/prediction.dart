class Prediction {
  final String id;
  final String? leagueId;
  final String homeTeam;
  final String awayTeam;
  final DateTime matchDate;
  final String tipType;
  final String prediction;
  final double? odds;
  final int confidence;
  final String? result;      // 'won','lost','pending','void'
  final bool isVip;
  final String? vipTier;
  final String? aiReasoning;
  final int? homeScore;
  final int? awayScore;
  final String status;       // 'pending','live','finished'
  final String leagueName;
  final String? leagueCountry;

  const Prediction({
    required this.id,
    this.leagueId,
    required this.homeTeam,
    required this.awayTeam,
    required this.matchDate,
    required this.tipType,
    required this.prediction,
    this.odds,
    required this.confidence,
    this.result,
    required this.isVip,
    this.vipTier,
    this.aiReasoning,
    this.homeScore,
    this.awayScore,
    required this.status,
    this.leagueName = '',
    this.leagueCountry,
  });

  factory Prediction.fromJson(Map<String, dynamic> json) {
    return Prediction(
      id: json['id'] as String,
      leagueId: json['league_id'] as String?,
      homeTeam: json['home_team'] as String,
      awayTeam: json['away_team'] as String,
      matchDate: DateTime.parse(json['match_date'] as String),
      tipType: json['tip_type'] as String,
      prediction: json['prediction'] as String,
      odds: json['odds'] != null ? (json['odds'] as num).toDouble() : null,
      confidence: json['confidence'] as int? ?? 70,
      result: json['result'] as String?,
      isVip: json['is_vip'] as bool? ?? false,
      vipTier: json['vip_tier'] as String?,
      aiReasoning: json['ai_reasoning'] as String?,
      homeScore: json['home_score'] as int?,
      awayScore: json['away_score'] as int?,
      status: json['status'] as String? ?? 'pending',
      leagueName: (json['leagues'] as Map<String, dynamic>?)?['name'] as String? ?? '',
      leagueCountry: (json['leagues'] as Map<String, dynamic>?)?['country'] as String?,
    );
  }

  bool get isLive => status == 'live';
  bool get isFinished => status == 'finished';
  bool get isWon => result == 'won';
  bool get isLost => result == 'lost';
}
