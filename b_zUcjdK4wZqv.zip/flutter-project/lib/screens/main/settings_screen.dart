import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:pitch_prophet/core/theme.dart';
import 'package:pitch_prophet/services/supabase_service.dart';
import 'package:url_launcher/url_launcher.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkMode     = true;
  bool _notifications = true;
  bool _showCredits  = false;

  final _creditPacks = const [
    {'credits': 10,  'price': 2,  'label': 'Starter',  'badge': null},
    {'credits': 30,  'price': 5,  'label': 'Popular',  'badge': 'BEST VALUE'},
    {'credits': 100, 'price': 12, 'label': 'Pro',      'badge': null},
  ];

  void _buyCreditsTelegram(Map pack) {
    final msg = Uri.encodeComponent(
        "Hi! I'd like to buy ${pack['credits']} AI Credits for \$${pack['price']} on PitchProphet.");
    launchUrl(Uri.parse('https://t.me/pitchprophet?text=$msg'),
        mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Profile header
            Row(
              children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.purple.withOpacity(0.2),
                    border: Border.all(color: AppTheme.purple),
                  ),
                  child: const Icon(Icons.person, color: AppTheme.purple, size: 28),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('User Account',
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                      const Text('user@email.com',
                          style: TextStyle(fontSize: 11, color: AppTheme.textSecond)),
                      const SizedBox(height: 4),
                      Row(children: const [
                        Icon(Icons.bolt, size: 12, color: AppTheme.purple),
                        SizedBox(width: 3),
                        Text('10 AI Credits',
                            style: TextStyle(fontSize: 11, color: AppTheme.purple, fontWeight: FontWeight.w600)),
                      ]),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppTheme.gold,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Text('UPGRADE',
                      style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: Color(0xFF0D0D0D))),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // Stats
            Row(children: [
              _statBox('9', 'Teams', AppTheme.purple),
              const SizedBox(width: 8),
              _statBox('0', 'Matches', AppTheme.textSecond),
              const SizedBox(width: 8),
              _statBox('128', 'Leagues', AppTheme.gold),
            ]),
            const SizedBox(height: 14),

            // Buy credits toggle
            _menuItem(
              icon: Icons.shopping_cart_outlined,
              iconBg: AppTheme.purple.withOpacity(0.1),
              iconColor: AppTheme.purple,
              title: 'Buy AI Credits',
              sub: 'Power your AI analysis',
              trailing: Icon(_showCredits ? Icons.expand_less : Icons.chevron_right,
                  color: AppTheme.textSecond, size: 20),
              onTap: () => setState(() => _showCredits = !_showCredits),
            ),

            if (_showCredits) ...[
              const SizedBox(height: 8),
              ..._creditPacks.map((pkg) => Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: AppTheme.card,
                  border: Border.all(
                    color: pkg['badge'] != null
                        ? AppTheme.gold.withOpacity(0.4)
                        : AppTheme.border,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: pkg['badge'] != null
                      ? [BoxShadow(color: AppTheme.gold.withOpacity(0.1), blurRadius: 12)]
                      : [],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (pkg['badge'] != null)
                            Container(
                              margin: const EdgeInsets.only(bottom: 3),
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppTheme.gold.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(pkg['badge'] as String,
                                  style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: AppTheme.gold)),
                            ),
                          Text('${pkg['credits']} Credits',
                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                          Text(pkg['label'] as String,
                              style: const TextStyle(fontSize: 10, color: AppTheme.textSecond)),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => _buyCreditsTelegram(pkg),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: AppTheme.purple,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text('\$${pkg['price']}',
                            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
              )),
              const Text(
                'Pay via Telegram / PayPal / Bank Transfer',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 9, color: AppTheme.textSecond),
              ),
              const SizedBox(height: 8),
            ],

            _sectionHeader('Preferences'),
            _settingsCard(children: [
              _toggleItem(
                icon: Icons.dark_mode_outlined,
                title: 'Dark Mode',
                sub: 'Use dark theme',
                value: _darkMode,
                onChanged: (v) => setState(() => _darkMode = v),
              ),
              const Divider(height: 1, color: AppTheme.border),
              _navItem(icon: Icons.language, title: 'Language', sub: 'Device Default'),
            ]),

            _sectionHeader('Notifications'),
            _settingsCard(children: [
              _toggleItem(
                icon: Icons.notifications_outlined,
                title: 'Push Notifications',
                sub: 'Enabled',
                value: _notifications,
                onChanged: (v) => setState(() => _notifications = v),
              ),
            ]),

            _sectionHeader('Account'),
            _settingsCard(children: [
              _navItem(icon: Icons.person_outline, title: 'Personal Information', sub: 'Edit your profile'),
              const Divider(height: 1, color: AppTheme.border),
              _navItem(icon: Icons.lock_outline, title: 'Password', sub: 'Change your password'),
              const Divider(height: 1, color: AppTheme.border),
              _menuItem(
                icon: Icons.logout,
                iconBg: AppTheme.red.withOpacity(0.1),
                iconColor: AppTheme.red,
                title: 'Logout',
                titleColor: AppTheme.red,
                sub: 'Sign out of your account',
                onTap: () async {
                  await SupabaseService.signOut();
                  if (context.mounted) context.go('/login');
                },
              ),
            ]),

            _sectionHeader('About'),
            _settingsCard(children: [
              _navItem(icon: Icons.article_outlined, title: 'Terms of Use (EULA)', sub: 'View terms of use'),
              const Divider(height: 1, color: AppTheme.border),
              _navItem(icon: Icons.shield_outlined, title: 'Privacy Policy', sub: 'View privacy policy'),
              const Divider(height: 1, color: AppTheme.border),
              _navItem(icon: Icons.group_outlined, title: 'User Information Text', sub: 'Membership agreement'),
              const Divider(height: 1, color: AppTheme.border),
              _menuItem(
                icon: Icons.support_agent,
                iconBg: AppTheme.green.withOpacity(0.1),
                iconColor: AppTheme.green,
                title: 'Customer Support',
                sub: 'Get priority support service',
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.gold.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('PREMIUM',
                        style: TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: AppTheme.gold)),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.chevron_right, color: AppTheme.textSecond, size: 18),
                ]),
                onTap: () => launchUrl(Uri.parse('https://t.me/pitchprophet'),
                    mode: LaunchMode.externalApplication),
              ),
            ]),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _statBox(String val, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppTheme.card,
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(children: [
          Text(val, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: color)),
          Text(label, style: const TextStyle(fontSize: 9, color: AppTheme.textSecond)),
        ]),
      ),
    );
  }

  Widget _sectionHeader(String label) => Padding(
    padding: const EdgeInsets.only(top: 16, bottom: 6, left: 2),
    child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
  );

  Widget _settingsCard({required List<Widget> children}) => Container(
    decoration: BoxDecoration(
      color: AppTheme.card,
      border: Border.all(color: AppTheme.border),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Column(children: children),
  );

  Widget _navItem({required IconData icon, required String title, required String sub}) {
    return _menuItem(
      icon: icon,
      iconBg: AppTheme.surface,
      iconColor: AppTheme.textSecond,
      title: title,
      sub: sub,
      onTap: () {},
    );
  }

  Widget _menuItem({
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
    required String title,
    required String sub,
    Color? titleColor,
    Widget? trailing,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 34, height: 34,
              decoration: BoxDecoration(shape: BoxShape.circle, color: iconBg),
              child: Icon(icon, color: iconColor, size: 17),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: titleColor ?? AppTheme.textPrimary)),
                  Text(sub, style: const TextStyle(fontSize: 10, color: AppTheme.textSecond)),
                ],
              ),
            ),
            trailing ?? const Icon(Icons.chevron_right, color: AppTheme.textSecond, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _toggleItem({
    required IconData icon,
    required String title,
    required String sub,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(shape: BoxShape.circle, color: AppTheme.surface),
            child: Icon(icon, color: AppTheme.textSecond, size: 17),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.textPrimary)),
              Text(sub, style: const TextStyle(fontSize: 10, color: AppTheme.textSecond)),
            ]),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: AppTheme.purple,
            inactiveTrackColor: AppTheme.surface,
          ),
        ],
      ),
    );
  }
}
