import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pitch_prophet/core/theme.dart';
import 'package:pitch_prophet/models/prediction.dart';
import 'package:pitch_prophet/services/supabase_service.dart';
import 'package:pitch_prophet/widgets/tip_card.dart';
import 'package:url_launcher/url_launcher.dart';

const _tiers = [
  {'id': 'odds2',         'label': 'Odds 2+',       'icon': '2'},
  {'id': 'correct_score', 'label': 'Correct Score',  'icon': 'CS'},
  {'id': 'ht_ft',         'label': 'HT/FT',          'icon': 'HT'},
  {'id': 'odds5',         'label': 'Odds 5+',        'icon': '5'},
  {'id': 'super_combo',   'label': 'Super Combo',    'icon': 'SC'},
  {'id': 'over_under',    'label': 'Over/Under',     'icon': 'O/U'},
  {'id': 'all_access',    'label': 'All Access',     'icon': '★'},
];

const _tierPrices = {
  'odds2':         {'weekly': 5,  'monthly': 15, 'quarterly': 35},
  'correct_score': {'weekly': 8,  'monthly': 22, 'quarterly': 55},
  'ht_ft':         {'weekly': 8,  'monthly': 22, 'quarterly': 55},
  'odds5':         {'weekly': 10, 'monthly': 28, 'quarterly': 70},
  'super_combo':   {'weekly': 10, 'monthly': 28, 'quarterly': 70},
  'over_under':    {'weekly': 5,  'monthly': 15, 'quarterly': 35},
  'all_access':    {'weekly': 20, 'monthly': 55, 'quarterly': 130},
};

final vipTipsProvider =
    FutureProvider.family<List<Prediction>, String>((ref, tier) async {
  return SupabaseService.getVipTips(tier);
});

class VipScreen extends ConsumerStatefulWidget {
  const VipScreen({super.key});

  @override
  ConsumerState<VipScreen> createState() => _VipScreenState();
}

class _VipScreenState extends ConsumerState<VipScreen> {
  String _activeTier = 'odds2';
  String _activePlan = 'monthly';

  String get _tierLabel =>
      _tiers.firstWhere((t) => t['id'] == _activeTier)['label']!;

  int get _price => _tierPrices[_activeTier]![_activePlan]!;

  void _subscribe() {
    final msg = Uri.encodeComponent(
        "Hi! I'd like to subscribe to PitchProphet VIP - $_tierLabel ($_activePlan plan - \$$_price)");
    launchUrl(Uri.parse('https://t.me/pitchprophet?text=$msg'),
        mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final tipsAsync = ref.watch(vipTipsProvider(_activeTier));

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Row(
                children: const [
                  Icon(Icons.workspace_premium, color: AppTheme.gold, size: 22),
                  SizedBox(width: 8),
                  Text('VIP Tips',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: AppTheme.textPrimary)),
                ],
              ),
            ),

            // Tier selector (horizontal scroll)
            SizedBox(
              height: 70,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: _tiers.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (ctx, i) {
                  final tier = _tiers[i];
                  final isActive = _activeTier == tier['id'];
                  return GestureDetector(
                    onTap: () => setState(() => _activeTier = tier['id']!),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: isActive
                            ? AppTheme.gold.withOpacity(0.15)
                            : AppTheme.card,
                        border: Border.all(
                          color: isActive
                              ? AppTheme.gold
                              : AppTheme.border,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            tier['icon']!,
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: isActive
                                    ? AppTheme.gold
                                    : AppTheme.textSecond),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            tier['label']!,
                            style: TextStyle(
                                fontSize: 9,
                                color: isActive
                                    ? AppTheme.gold
                                    : AppTheme.textSecond,
                                fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 8),

            // Tips list
            Expanded(
              child: tipsAsync.when(
                loading: () => const Center(
                    child: CircularProgressIndicator(
                        color: AppTheme.purple, strokeWidth: 2)),
                error: (_, __) => const Center(
                    child: Text('Error',
                        style: TextStyle(color: AppTheme.textSecond))),
                data: (tips) => ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                  itemCount: tips.isEmpty ? 1 : tips.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (ctx, i) {
                    if (tips.isEmpty) {
                      return Center(
                        child: Column(
                          children: const [
                            SizedBox(height: 60),
                            Icon(Icons.lock_outline,
                                color: AppTheme.textSecond, size: 36),
                            SizedBox(height: 8),
                            Text('Subscribe to see VIP tips',
                                style: TextStyle(color: AppTheme.textSecond)),
                          ],
                        ),
                      );
                    }
                    return TipCardWidget(tip: tips[i], locked: true);
                  },
                ),
              ),
            ),

            // Pricing card
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.card,
                border: Border.all(color: AppTheme.gold.withOpacity(0.5)),
                borderRadius: BorderRadius.circular(18),
                boxShadow: [
                  BoxShadow(
                      color: AppTheme.gold.withOpacity(0.12), blurRadius: 16)
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.workspace_premium,
                          color: AppTheme.gold, size: 18),
                      const SizedBox(width: 6),
                      Text(_tierLabel,
                          style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.gold)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  // Plan selector
                  Row(
                    children: [
                      for (final plan in ['weekly', 'monthly', 'quarterly'])
                        Expanded(
                          child: GestureDetector(
                            onTap: () => setState(() => _activePlan = plan),
                            child: Container(
                              margin: EdgeInsets.only(right: plan != 'quarterly' ? 6 : 0),
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: _activePlan == plan
                                    ? AppTheme.purple.withOpacity(0.2)
                                    : AppTheme.surface,
                                border: Border.all(
                                  color: _activePlan == plan
                                      ? AppTheme.purple
                                      : AppTheme.border,
                                ),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                plan == 'quarterly' ? '3 Months' : plan[0].toUpperCase() + plan.substring(1),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: _activePlan == plan
                                        ? AppTheme.purple
                                        : AppTheme.textSecond),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Center(
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: '\$$_price',
                            style: const TextStyle(
                                fontSize: 32,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.textPrimary),
                          ),
                          TextSpan(
                            text: ' / $_activePlan',
                            style: const TextStyle(
                                fontSize: 12, color: AppTheme.textSecond),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _subscribe,
                    icon: const Icon(Icons.message, size: 16),
                    label: const Text('Subscribe via Telegram',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.purple,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Also on WhatsApp  •  Pay via PayPal or bank transfer',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 9, color: AppTheme.textSecond),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
