import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:pitch_prophet/core/theme.dart';
import 'package:pitch_prophet/models/prediction.dart';
import 'package:pitch_prophet/services/supabase_service.dart';

final historyProvider = FutureProvider<List<Prediction>>((ref) async {
  return SupabaseService.getHistory();
});

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final historyAsync = ref.watch(historyProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Row(children: const [
                Icon(Icons.bar_chart, color: AppTheme.purple, size: 22),
                SizedBox(width: 8),
                Text('History', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppTheme.textPrimary)),
              ]),
            ),
            Expanded(
              child: historyAsync.when(
                loading: () => const Center(child: CircularProgressIndicator(color: AppTheme.purple, strokeWidth: 2)),
                error: (_, __) => const Center(child: Text('Error loading history', style: TextStyle(color: AppTheme.textSecond))),
                data: (tips) {
                  final won   = tips.where((t) => t.result == 'won').length;
                  final lost  = tips.where((t) => t.result == 'lost').length;
                  final total = tips.length;
                  final rate  = total > 0 ? (won / total * 100).round() : 0;

                  return ListView(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                    children: [
                      // Stats card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.card,
                          border: Border.all(color: AppTheme.border),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: const [
                              Icon(Icons.trending_up, color: AppTheme.green, size: 18),
                              SizedBox(width: 6),
                              Text('Overall Performance', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                            ]),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(child: _StatItem(label: 'Won', value: '$won', color: AppTheme.green)),
                                Expanded(child: _StatItem(label: 'Lost', value: '$lost', color: AppTheme.red)),
                                Expanded(child: _StatItem(label: 'Win Rate', value: '$rate%', color: AppTheme.purple)),
                              ],
                            ),
                            const SizedBox(height: 10),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: total > 0 ? won / total : 0,
                                backgroundColor: AppTheme.surface,
                                valueColor: const AlwaysStoppedAnimation(AppTheme.green),
                                minHeight: 6,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      const Text('Recent Results', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                      const SizedBox(height: 8),

                      if (tips.isEmpty)
                        const Padding(
                          padding: EdgeInsets.only(top: 40),
                          child: Center(child: Text('No finished tips yet', style: TextStyle(color: AppTheme.textSecond))),
                        )
                      else
                        ...tips.map((tip) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppTheme.card,
                              border: Border.all(
                                color: tip.result == 'won'
                                    ? AppTheme.green.withOpacity(0.3)
                                    : AppTheme.red.withOpacity(0.3),
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${tip.leagueName}  •  ${DateFormat('dd MMM').format(tip.matchDate)}',
                                        style: const TextStyle(fontSize: 9, color: AppTheme.textSecond),
                                      ),
                                      const SizedBox(height: 2),
                                      Text('${tip.homeTeam} vs ${tip.awayTeam}',
                                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.textPrimary)),
                                      Text(tip.prediction,
                                          style: const TextStyle(fontSize: 10, color: AppTheme.purple)),
                                    ],
                                  ),
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      '${tip.homeScore} - ${tip.awayScore}',
                                      style: TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.w900,
                                          color: tip.result == 'won' ? AppTheme.green : AppTheme.red),
                                    ),
                                    Icon(
                                      tip.result == 'won' ? Icons.check_circle : Icons.cancel,
                                      color: tip.result == 'won' ? AppTheme.green : AppTheme.red,
                                      size: 16,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        )),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StatItem({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
      Text(label.toUpperCase(), style: const TextStyle(fontSize: 9, color: AppTheme.textSecond)),
    ]);
  }
}
