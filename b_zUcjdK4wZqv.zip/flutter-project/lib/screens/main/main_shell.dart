import 'package:flutter/material.dart';
import 'package:pitch_prophet/core/theme.dart';
import 'package:pitch_prophet/screens/main/free_tips_screen.dart';
import 'package:pitch_prophet/screens/main/vip_screen.dart';
import 'package:pitch_prophet/screens/main/ai_screen.dart';
import 'package:pitch_prophet/screens/main/history_screen.dart';
import 'package:pitch_prophet/screens/main/settings_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    FreeTipsScreen(),
    VipScreen(),
    AiScreen(),
    HistoryScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF121212),
        border: Border(top: BorderSide(color: AppTheme.border, width: 1)),
      ),
      child: SafeArea(
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              _buildNavItem(0, Icons.home_outlined, Icons.home, 'Home'),
              _buildNavItem(1, Icons.workspace_premium_outlined, Icons.workspace_premium, 'VIP'),
              // Center AI button
              Expanded(
                child: Center(
                  child: GestureDetector(
                    onTap: () => setState(() => _currentIndex = 2),
                    child: Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: AppTheme.purple,
                        shape: BoxShape.circle,
                        boxShadow: _currentIndex == 2
                            ? [BoxShadow(
                                color: AppTheme.purple.withOpacity(0.5),
                                blurRadius: 16, spreadRadius: 2)]
                            : [],
                      ),
                      child: const Icon(Icons.bolt, color: Colors.white, size: 26),
                    ),
                  ),
                ),
              ),
              _buildNavItem(3, Icons.bar_chart_outlined, Icons.bar_chart, 'History'),
              _buildNavItem(4, Icons.tune_outlined, Icons.tune, 'Profile'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, IconData activeIcon, String label) {
    final isActive = _currentIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _currentIndex = index),
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isActive ? activeIcon : icon,
              color: isActive ? AppTheme.purple : AppTheme.textSecond,
              size: 22,
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: isActive ? AppTheme.purple : AppTheme.textSecond,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
