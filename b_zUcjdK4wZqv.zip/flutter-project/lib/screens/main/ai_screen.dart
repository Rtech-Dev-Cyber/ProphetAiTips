import 'package:flutter/material.dart';
import 'package:pitch_prophet/core/theme.dart';

// ignore_for_file: use_build_context_synchronously

class AiScreen extends StatefulWidget {
  const AiScreen({super.key});

  @override
  State<AiScreen> createState() => _AiScreenState();
}

class _AiScreenState extends State<AiScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  // Coupon builder
  final _selectedDates   = <String>{'today'};
  String _selectedLeague = '';
  final _selectedBetTypes = <String>{'1x2', 'over_under'};
  int _matchCount        = 3;
  bool _loadingCoupon    = false;
  List<Map<String, dynamic>>? _coupon;

  // Ask AI
  final _questionCtrl = TextEditingController();
  bool _askLoading    = false;
  String? _aiResponse;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    _questionCtrl.dispose();
    super.dispose();
  }

  Future<void> _generateCoupon() async {
    setState(() { _loadingCoupon = true; _coupon = null; });
    await Future.delayed(const Duration(milliseconds: 1400));
    setState(() {
      _coupon = List.generate(_matchCount, (i) {
        final matches = [
          {'home': 'Arsenal',    'away': 'Chelsea',    'pred': 'Arsenal Win',   'odds': 1.85, 'league': 'Premier League'},
          {'home': 'Barcelona',  'away': 'Real Madrid','pred': 'Over 2.5',      'odds': 1.65, 'league': 'La Liga'},
          {'home': 'Bayern',     'away': 'Dortmund',   'pred': 'BTTS - Yes',    'odds': 1.72, 'league': 'Bundesliga'},
          {'home': 'Inter',      'away': 'Juventus',   'pred': 'Draw',          'odds': 3.20, 'league': 'Serie A'},
          {'home': 'Ajax',       'away': 'PSV',        'pred': 'Ajax Win',      'odds': 2.10, 'league': 'Eredivisie'},
          {'home': 'Galatasaray','away': 'Fenerbahce', 'pred': 'Over 2.5',      'odds': 1.70, 'league': 'Super Lig'},
        ];
        return matches[i % matches.length];
      });
      _loadingCoupon = false;
    });
  }

  Future<void> _askAi() async {
    if (_questionCtrl.text.trim().isEmpty) return;
    setState(() { _askLoading = true; _aiResponse = null; });
    await Future.delayed(const Duration(milliseconds: 1800));
    setState(() {
      _aiResponse =
          'Based on recent form and head-to-head data for "${_questionCtrl.text}":\n\n'
          'The home team has won 6 of their last 8 meetings. Key factors include current league position, '
          'recent scoring form, and injury news. Both teams have been scoring freely.\n\n'
          'Confidence: 76%  •  Recommended odds: 1.75–2.10';
      _askLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: const [
                  Icon(Icons.bolt, color: AppTheme.purple, size: 22),
                  SizedBox(width: 8),
                  Text('AI Centre',
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: AppTheme.textPrimary)),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Tab bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.border),
                ),
                child: TabBar(
                  controller: _tabCtrl,
                  indicator: BoxDecoration(
                    color: AppTheme.purple,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: AppTheme.textSecond,
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'Smart Coupon'),
                    Tab(text: 'Ask AI'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            Expanded(
              child: TabBarView(
                controller: _tabCtrl,
                children: [
                  _buildCouponBuilder(),
                  _buildAskAi(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCouponBuilder() {
    final leagues = ['Premier League', 'La Liga', 'Bundesliga', 'Serie A', 'Ligue 1', 'Champions League'];
    final betTypes = [
      {'id': '1x2', 'icon': '1X2', 'label': 'Match Winner'},
      {'id': 'over_under', 'icon': '2.5', 'label': 'Over/Under 2.5'},
      {'id': 'btts', 'icon': '0|1', 'label': 'Both Teams Score'},
      {'id': 'double_chance', 'icon': 'x2', 'label': 'Double Chance'},
    ];
    final dates = [
      {'id': 'today',    'label': 'Today'},
      {'id': 'tomorrow', 'label': 'Tomorrow'},
      {'id': 'dayafter', 'label': 'Day After'},
    ];

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      children: [
        // Date selection
        _sectionCard(
          icon: Icons.calendar_today,
          title: 'Date Selection',
          sub: 'Select days for predictions',
          child: Column(
            children: dates.map((d) {
              final selected = _selectedDates.contains(d['id']);
              return GestureDetector(
                onTap: () => setState(() {
                  selected ? _selectedDates.remove(d['id']) : _selectedDates.add(d['id']!);
                }),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: selected ? AppTheme.purple.withOpacity(0.15) : AppTheme.surface,
                    border: Border.all(
                        color: selected ? AppTheme.purple : AppTheme.border),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(d['label']!,
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: selected
                                  ? AppTheme.purple
                                  : AppTheme.textPrimary)),
                      if (selected) const Icon(Icons.check_circle, color: AppTheme.purple, size: 16),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 8),

        // League
        _sectionCard(
          icon: Icons.flag_outlined,
          title: 'League Selection',
          sub: 'Select a league',
          child: DropdownButtonFormField<String>(
            value: _selectedLeague.isEmpty ? null : _selectedLeague,
            items: leagues.map((l) => DropdownMenuItem(value: l, child: Text(l, style: const TextStyle(fontSize: 13, color: AppTheme.textPrimary)))).toList(),
            onChanged: (v) => setState(() => _selectedLeague = v ?? ''),
            hint: const Text('Select league', style: TextStyle(color: AppTheme.textSecond, fontSize: 13)),
            decoration: const InputDecoration(
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            ),
            dropdownColor: AppTheme.card,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
          ),
        ),
        const SizedBox(height: 8),

        // Bet types
        _sectionCard(
          icon: Icons.calculate_outlined,
          title: 'Bet Types',
          sub: 'Which bet types for predictions?',
          child: GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            crossAxisSpacing: 6,
            mainAxisSpacing: 6,
            physics: const NeverScrollableScrollPhysics(),
            children: betTypes.map((bt) {
              final active = _selectedBetTypes.contains(bt['id']);
              return GestureDetector(
                onTap: () => setState(() {
                  active ? _selectedBetTypes.remove(bt['id']) : _selectedBetTypes.add(bt['id']!);
                }),
                child: Column(
                  children: [
                    Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: active ? AppTheme.purple : AppTheme.surface,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(bt['icon']!,
                            style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w800,
                                color: active ? Colors.white : AppTheme.textSecond)),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(bt['label']!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 7, color: AppTheme.textSecond),
                        maxLines: 2),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 8),

        // Match count
        _sectionCard(
          icon: Icons.shuffle,
          title: 'Number of Matches',
          sub: 'How many per coupon? (2–6)',
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _circleBtn(Icons.remove, () => setState(() => _matchCount = (_matchCount - 1).clamp(2, 6))),
              const SizedBox(width: 24),
              Text('$_matchCount',
                  style: const TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w900, color: AppTheme.textPrimary)),
              const SizedBox(width: 24),
              _circleBtn(Icons.add, () => setState(() => _matchCount = (_matchCount + 1).clamp(2, 6))),
            ],
          ),
        ),
        const SizedBox(height: 12),

        // Generate button
        ElevatedButton.icon(
          onPressed: (_loadingCoupon || _selectedDates.isEmpty || _selectedBetTypes.isEmpty)
              ? null
              : _generateCoupon,
          icon: _loadingCoupon
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.bolt, size: 18),
          label: Text(_loadingCoupon ? 'Building Coupon...' : 'Create Coupon',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.purple,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),

        // Result coupon
        if (_coupon != null) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.card,
              border: Border.all(color: AppTheme.purple.withOpacity(0.4)),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Your Coupon',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppTheme.textPrimary)),
                    Text(
                      'Total: ${_coupon!.fold<double>(1.0, (acc, s) => acc * (s['odds'] as double)).toStringAsFixed(2)}x',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: AppTheme.gold),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ..._coupon!.map((s) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s['league'] as String,
                                style: const TextStyle(fontSize: 9, color: AppTheme.textSecond)),
                            Text('${s['home']} vs ${s['away']}',
                                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppTheme.textPrimary)),
                            Text(s['pred'] as String,
                                style: const TextStyle(fontSize: 10, color: AppTheme.purple)),
                          ],
                        ),
                      ),
                      Text('@${(s['odds'] as double).toStringAsFixed(2)}',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.gold)),
                    ],
                  ),
                )),
              ],
            ),
          ),
        ],
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildAskAi() {
    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.card,
            border: Border.all(color: AppTheme.border),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: const [
                  Icon(Icons.smart_toy_outlined, color: AppTheme.purple, size: 18),
                  SizedBox(width: 6),
                  Text('Ask AI Analyst',
                      style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppTheme.textPrimary)),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                'Ask anything about upcoming matches, team form, or predictions.',
                style: TextStyle(fontSize: 11, color: AppTheme.textSecond),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _questionCtrl,
                maxLines: 3,
                style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
                decoration: const InputDecoration(
                  hintText: 'e.g. Who will win Arsenal vs Chelsea this weekend?',
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: (_askLoading || _questionCtrl.text.trim().isEmpty) ? null : _askAi,
                icon: _askLoading
                    ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.bolt, size: 16),
                label: Text(_askLoading ? 'Analysing...' : 'Get AI Analysis',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.purple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ],
          ),
        ),
        if (_aiResponse != null) ...[
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.card,
              border: Border.all(color: AppTheme.purple.withOpacity(0.4)),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: const [
                  Icon(Icons.smart_toy_outlined, color: AppTheme.purple, size: 16),
                  SizedBox(width: 6),
                  Text('AI Analysis', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.purple)),
                ]),
                const SizedBox(height: 8),
                Text(_aiResponse!, style: const TextStyle(fontSize: 12, color: AppTheme.textPrimary, height: 1.5)),
                const SizedBox(height: 8),
                Row(children: const [
                  Icon(Icons.bolt, size: 12, color: AppTheme.textSecond),
                  SizedBox(width: 4),
                  Text('1 credit used  •  9 remaining', style: TextStyle(fontSize: 9, color: AppTheme.textSecond)),
                ]),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _sectionCard({
    required IconData icon,
    required String title,
    required String sub,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: AppTheme.purple, size: 16),
            const SizedBox(width: 6),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppTheme.textPrimary)),
          ]),
          const SizedBox(height: 2),
          Text(sub, style: const TextStyle(fontSize: 10, color: AppTheme.textSecond)),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  Widget _circleBtn(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: AppTheme.purple),
        ),
        child: Icon(icon, color: AppTheme.purple, size: 18),
      ),
    );
  }
}
