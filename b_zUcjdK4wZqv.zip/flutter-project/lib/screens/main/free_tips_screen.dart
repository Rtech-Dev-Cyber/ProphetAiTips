import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:pitch_prophet/core/theme.dart';
import 'package:pitch_prophet/models/prediction.dart';
import 'package:pitch_prophet/services/supabase_service.dart';
import 'package:pitch_prophet/widgets/tip_card.dart';

final freeTipsProvider = FutureProvider<List<Prediction>>((ref) async {
  return SupabaseService.getFreeTips();
});

class FreeTipsScreen extends ConsumerWidget {
  const FreeTipsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tipsAsync = ref.watch(freeTipsProvider);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('PitchProphet',
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                color: AppTheme.textPrimary)),
                        Text(
                          DateFormat('EEEE, dd MMM yyyy').format(DateTime.now()),
                          style: const TextStyle(
                              fontSize: 11, color: AppTheme.textSecond),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppTheme.purple,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.bolt, color: Colors.white, size: 14),
                        SizedBox(width: 4),
                        Text('FREE',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Stats row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _StatCard(label: 'Win Rate', value: '72%', color: AppTheme.green, icon: Icons.trending_up),
                  const SizedBox(width: 8),
                  _StatCard(label: "Today's Tips", value: '8', color: AppTheme.purple, icon: Icons.gps_fixed),
                  const SizedBox(width: 8),
                  _StatCard(label: 'Avg Odds', value: '1.85', color: AppTheme.gold, icon: Icons.bar_chart),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Section header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Today's Predictions",
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimary)),
                  tipsAsync.when(
                    data: (tips) => Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppTheme.surface,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text('${tips.length} tips',
                          style: const TextStyle(
                              fontSize: 10, color: AppTheme.textSecond)),
                    ),
                    loading: () => const SizedBox(),
                    error: (_, __) => const SizedBox(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),

            // Tips list
            Expanded(
              child: tipsAsync.when(
                loading: () => const Center(
                    child: CircularProgressIndicator(
                        color: AppTheme.purple, strokeWidth: 2)),
                error: (e, _) => Center(
                    child: Text('Error loading tips',
                        style: const TextStyle(color: AppTheme.textSecond))),
                data: (tips) => ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  itemCount: tips.isEmpty ? 1 : tips.length + 1,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (ctx, i) {
                    if (tips.isEmpty) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.only(top: 60),
                          child: Text('No tips for today yet',
                              style: TextStyle(color: AppTheme.textSecond)),
                        ),
                      );
                    }
                    if (i == tips.length) {
                      // Upgrade banner at bottom
                      return Container(
                        margin: const EdgeInsets.only(top: 8),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          border: Border.all(
                              color: AppTheme.gold.withOpacity(0.4)),
                          borderRadius: BorderRadius.circular(16),
                          color: AppTheme.card,
                          boxShadow: [
                            BoxShadow(
                                color: AppTheme.gold.withOpacity(0.15),
                                blurRadius: 16)
                          ],
                        ),
                        child: Column(
                          children: [
                            const Text('UNLOCK VIP TIPS',
                                style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.gold,
                                    letterSpacing: 1)),
                            const SizedBox(height: 4),
                            const Text(
                                'Get Correct Score, HT/FT, Odds 5+ and more',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 11, color: AppTheme.textSecond)),
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 8),
                              decoration: BoxDecoration(
                                color: AppTheme.gold,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text('View VIP Plans',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: Color(0xFF0D0D0D))),
                            ),
                          ],
                        ),
                      );
                    }
                    return TipCardWidget(tip: tips[i]);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final IconData icon;

  const _StatCard({
    required this.label,
    required this.value,
    required this.color,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppTheme.card,
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(height: 4),
            Text(value,
                style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: color)),
            Text(label,
                style: const TextStyle(
                    fontSize: 9, color: AppTheme.textSecond)),
          ],
        ),
      ),
    );
  }
}
