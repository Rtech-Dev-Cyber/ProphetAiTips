import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:pitch_prophet/screens/splash_screen.dart';
import 'package:pitch_prophet/screens/auth/login_screen.dart';
import 'package:pitch_prophet/screens/auth/signup_screen.dart';
import 'package:pitch_prophet/screens/main/main_shell.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/splash',
    routes: [
      GoRoute(
        path: '/splash',
        builder: (ctx, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/login',
        builder: (ctx, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/signup',
        builder: (ctx, state) => const SignUpScreen(),
      ),
      GoRoute(
        path: '/app',
        builder: (ctx, state) => const MainShell(),
      ),
    ],
  );
});
