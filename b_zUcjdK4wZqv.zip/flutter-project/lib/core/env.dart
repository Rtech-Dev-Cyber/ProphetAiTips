/// PitchProphet – App-level configuration constants
///
/// HOW TO FILL THESE IN:
///
/// 1. SUPABASE_URL & SUPABASE_ANON_KEY
///    → supabase.com → Open your project → Settings → API
///    → Copy "Project URL" and "anon public" key
///
/// 2. BACKEND_URL
///    → The public URL of your deployed Node.js backend
///    → Free options: Railway (railway.app), Render (render.com), Fly.io
///    → After deploying, copy the URL shown on the dashboard
///    → e.g. https://pitchprophet-backend.railway.app
///
/// NOTE: The ANON key is safe to include in Flutter apps — it is public.
///       The SERVICE_ROLE key is secret and must NEVER be in Flutter code,
///       it belongs only in the backend .env file.

class Env {
  Env._();

  // ── Supabase ──────────────────────────────────────────────────────────────
  static const supabaseUrl = 'https://hsmqxcdnzxfuwzbwzfyy.supabase.co';

  // anon / publishable key — safe to include in Flutter
  static const supabaseAnonKey = 'sb_publishable_ZrItdl2d79xhzLn-o0qIqA_Mpqb6qNf';

  // ── Backend ───────────────────────────────────────────────────────────────
  static const backendUrl = 'YOUR_BACKEND_URL';
  // e.g. 'https://pitchprophet-backend.railway.app'
}
