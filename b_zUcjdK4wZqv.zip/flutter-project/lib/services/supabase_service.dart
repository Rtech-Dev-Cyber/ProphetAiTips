import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:pitch_prophet/models/prediction.dart';
import 'package:pitch_prophet/models/profile.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;

  // ── Auth ──────────────────────────────────────────────────────────────────

  static Future<AuthResponse> signUp({
    required String email,
    required String password,
    String? fullName,
  }) async {
    return client.auth.signUp(
      email: email,
      password: password,
      data: fullName != null ? {'full_name': fullName} : null,
    );
  }

  static Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    return client.auth.signInWithPassword(email: email, password: password);
  }

  static Future<void> signOut() => client.auth.signOut();

  static User? get currentUser => client.auth.currentUser;

  static Stream<AuthState> get authStateChanges =>
      client.auth.onAuthStateChange;

  // ── Profile ───────────────────────────────────────────────────────────────

  static Future<UserProfile?> getProfile(String userId) async {
    final data = await client
        .from('profiles')
        .select()
        .eq('id', userId)
        .single();
    return UserProfile.fromJson(data);
  }

  static Future<void> updateProfile({
    required String userId,
    String? fullName,
    String? avatarUrl,
  }) async {
    await client.from('profiles').update({
      if (fullName != null) 'full_name': fullName,
      if (avatarUrl != null) 'avatar_url': avatarUrl,
      'updated_at': DateTime.now().toIso8601String(),
    }).eq('id', userId);
  }

  // ── Predictions ───────────────────────────────────────────────────────────

  static Future<List<Prediction>> getFreeTips({DateTime? date}) async {
    final targetDate = date ?? DateTime.now();
    final start = DateTime(targetDate.year, targetDate.month, targetDate.day);
    final end = start.add(const Duration(days: 1));

    final data = await client
        .from('predictions')
        .select('*, leagues(name, country)')
        .eq('is_vip', false)
        .gte('match_date', start.toIso8601String())
        .lt('match_date', end.toIso8601String())
        .order('match_date', ascending: true);

    return (data as List).map((e) => Prediction.fromJson(e)).toList();
  }

  static Future<List<Prediction>> getVipTips(String tier) async {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day);
    final end = start.add(const Duration(days: 1));

    final query = client
        .from('predictions')
        .select('*, leagues(name, country)')
        .eq('is_vip', true)
        .gte('match_date', start.toIso8601String())
        .lt('match_date', end.toIso8601String());

    if (tier != 'all_access') {
      query.eq('vip_tier', tier);
    }

    final data = await query.order('match_date', ascending: true);
    return (data as List).map((e) => Prediction.fromJson(e)).toList();
  }

  static Future<List<Prediction>> getHistory({int limit = 30}) async {
    final data = await client
        .from('predictions')
        .select('*, leagues(name, country)')
        .eq('status', 'finished')
        .order('match_date', ascending: false)
        .limit(limit);
    return (data as List).map((e) => Prediction.fromJson(e)).toList();
  }

  // ── VIP Subscriptions ─────────────────────────────────────────────────────

  static Future<List<VipSubscription>> getUserVipSubscriptions(
      String userId) async {
    final data = await client
        .from('vip_subscriptions')
        .select()
        .eq('user_id', userId)
        .gt('expires_at', DateTime.now().toIso8601String())
        .order('expires_at', ascending: false);
    return (data as List).map((e) => VipSubscription.fromJson(e)).toList();
  }

  // ── Coupon Builder ────────────────────────────────────────────────────────

  static Future<void> saveCoupon({
    required String userId,
    required List<Map<String, dynamic>> selections,
    required double totalOdds,
  }) async {
    await client.from('coupon_tips').insert({
      'user_id': userId,
      'selections': selections,
      'total_odds': totalOdds,
    });
  }

  // ── Credits ───────────────────────────────────────────────────────────────

  static Future<void> deductCredit(String userId) async {
    final profile = await getProfile(userId);
    if (profile == null || profile.aiCredits <= 0) {
      throw Exception('Insufficient AI credits');
    }
    await client.from('profiles').update({
      'ai_credits': profile.aiCredits - 1,
    }).eq('id', userId);

    await client.from('ai_credits_log').insert({
      'user_id': userId,
      'amount': -1,
      'reason': 'AI ask query',
    });
  }
}
