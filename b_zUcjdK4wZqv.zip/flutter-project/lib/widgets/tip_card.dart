import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pitch_prophet/core/theme.dart';
import 'package:pitch_prophet/models/prediction.dart';

const Map<String, String> _tipTypeLabel = {
  '1x2': '1X2',
  'over_under': 'O/U',
  'btts': 'BTTS',
  'double_chance': 'DC',
  'correct_score': 'CS',
  'ht_ft': 'HT/FT',
};

class TipCardWidget extends StatelessWidget {
  final Prediction tip;
  final bool locked;

  const TipCardWidget({super.key, required this.tip, this.locked = false});

  @override
  Widget build(BuildContext context) {
    final isWon  = tip.result == 'won';
    final isLost = tip.result == 'lost';
    final isLive = tip.isLive;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.card,
        border: Border.all(
          color: tip.isVip
              ? AppTheme.gold.withOpacity(0.35)
              : AppTheme.border,
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // League + date row
          Row(
            children: [
              if (isLive) ...[
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppTheme.red.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 5, height: 5,
                        decoration: const BoxDecoration(
                          color: AppTheme.red, shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 4),
                      const Text('LIVE',
                          style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.red)),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
              ],
              Expanded(
                child: Text(
                  tip.leagueName.toUpperCase(),
                  style: const TextStyle(
                      fontSize: 9,
                      color: AppTheme.textSecond,
                      letterSpacing: 0.4),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Text(
                DateFormat('dd MMM, HH:mm').format(tip.matchDate),
                style: const TextStyle(fontSize: 9, color: AppTheme.textSecond),
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Teams + score
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tip.homeTeam,
                        style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary)),
                    const SizedBox(height: 2),
                    const Text('vs',
                        style: TextStyle(fontSize: 9, color: AppTheme.textSecond)),
                    const SizedBox(height: 2),
                    Text(tip.awayTeam,
                        style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary)),
                  ],
                ),
              ),
              if (locked) ...[
                Column(
                  children: [
                    const Icon(Icons.lock_outline,
                        color: AppTheme.gold, size: 20),
                    const SizedBox(height: 2),
                    const Text('VIP',
                        style: TextStyle(
                            fontSize: 8,
                            color: AppTheme.gold,
                            fontWeight: FontWeight.w700)),
                  ],
                ),
              ] else if (tip.isFinished && tip.homeScore != null) ...[
                Text(
                  '${tip.homeScore} - ${tip.awayScore}',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: isWon
                        ? AppTheme.green
                        : isLost
                            ? AppTheme.red
                            : AppTheme.textPrimary,
                  ),
                ),
              ] else if (isLive) ...[
                Text(
                  '${tip.homeScore ?? 0} - ${tip.awayScore ?? 0}',
                  style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.red),
                ),
              ],
            ],
          ),
          const SizedBox(height: 10),

          // Prediction row or locked
          if (locked)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text('Subscribe to unlock prediction',
                      style: TextStyle(
                          fontSize: 11,
                          color: AppTheme.textSecond,
                          fontStyle: FontStyle.italic)),
                  Icon(Icons.lock_outline, size: 14, color: AppTheme.textSecond),
                ],
              ),
            )
          else
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppTheme.purple.withOpacity(0.25),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    _tipTypeLabel[tip.tipType] ?? tip.tipType.toUpperCase(),
                    style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.purple),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    tip.prediction,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimary),
                  ),
                ),
                if (tip.odds != null)
                  Text(
                    '@${tip.odds!.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.gold),
                  ),
                const SizedBox(width: 6),
                _resultIcon(tip),
              ],
            ),

          if (!locked) ...[
            const SizedBox(height: 8),
            // Confidence bar
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Confidence',
                    style: TextStyle(fontSize: 9, color: AppTheme.textSecond, letterSpacing: 0.4)),
                Text('${tip.confidence}%',
                    style: const TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.purple)),
              ],
            ),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: tip.confidence / 100,
                backgroundColor: AppTheme.surface,
                valueColor: AlwaysStoppedAnimation<Color>(AppTheme.purple),
                minHeight: 4,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _resultIcon(Prediction tip) {
    if (tip.result == 'won') {
      return const Icon(Icons.check_circle, color: AppTheme.green, size: 16);
    } else if (tip.result == 'lost') {
      return const Icon(Icons.cancel, color: AppTheme.red, size: 16);
    } else if (tip.isLive) {
      return const Icon(Icons.bolt, color: Colors.amber, size: 16);
    }
    return const Icon(Icons.access_time, color: AppTheme.textSecond, size: 14);
  }
}
