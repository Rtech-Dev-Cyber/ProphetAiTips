export type TipResult = 'won' | 'lost' | 'pending' | 'void'
export type TipStatus = 'pending' | 'live' | 'finished'
export type TipType = '1x2' | 'over_under' | 'btts' | 'double_chance' | 'correct_score' | 'ht_ft'
export type VipTier = 'odds2' | 'correct_score' | 'ht_ft' | 'odds5' | 'super_combo' | 'over_under' | 'all_access'
export type VipPlan = 'weekly' | 'monthly' | 'quarterly'

export interface Prediction {
  id: string
  league_id: string | null
  home_team: string
  away_team: string
  match_date: string
  tip_type: TipType
  prediction: string
  odds: number | null
  confidence: number
  result: TipResult
  is_vip: boolean
  vip_tier: VipTier | null
  ai_reasoning: string | null
  home_score: number | null
  away_score: number | null
  status: TipStatus
  created_at: string
  league?: League
}

export interface League {
  id: string
  name: string
  country: string | null
  logo_url: string | null
  api_id: number | null
  is_active: boolean
}

export interface Profile {
  id: string
  email: string | null
  full_name: string | null
  avatar_url: string | null
  is_admin: boolean
  ai_credits: number
  created_at: string
}

export interface VipSubscription {
  id: string
  user_id: string
  tier: VipTier
  plan: VipPlan
  started_at: string
  expires_at: string
  notes: string | null
  created_at: string
}

export interface CouponSelection {
  home_team: string
  away_team: string
  match_date: string
  prediction: string
  tip_type: TipType
  odds: number
  league: string
}

export const VIP_TIER_LABELS: Record<VipTier, string> = {
  odds2: 'Odds 2 Picks',
  correct_score: 'Correct Score',
  ht_ft: 'HT/FT',
  odds5: 'Odds 5 Picks',
  super_combo: 'Super Combo',
  over_under: 'Over/Under',
  all_access: 'All Access',
}

export const VIP_TIER_PRICES: Record<VipTier, Record<VipPlan, number>> = {
  odds2:         { weekly: 5,  monthly: 15, quarterly: 35 },
  correct_score: { weekly: 8,  monthly: 22, quarterly: 55 },
  ht_ft:         { weekly: 8,  monthly: 22, quarterly: 55 },
  odds5:         { weekly: 10, monthly: 28, quarterly: 70 },
  super_combo:   { weekly: 10, monthly: 28, quarterly: 70 },
  over_under:    { weekly: 5,  monthly: 15, quarterly: 35 },
  all_access:    { weekly: 20, monthly: 55, quarterly: 130 },
}

export const CREDIT_PACKAGES = [
  { credits: 10,  price: 2,  label: 'Starter' },
  { credits: 30,  price: 5,  label: 'Popular', badge: 'BEST VALUE' },
  { credits: 100, price: 12, label: 'Pro' },
]

export const MOCK_FREE_TIPS: Prediction[] = [
  {
    id: '1',
    league_id: null,
    home_team: 'Arsenal',
    away_team: 'Chelsea',
    match_date: new Date().toISOString(),
    tip_type: '1x2',
    prediction: 'Arsenal Win',
    odds: 1.85,
    confidence: 78,
    result: 'pending',
    is_vip: false,
    vip_tier: null,
    ai_reasoning: null,
    home_score: null,
    away_score: null,
    status: 'pending',
    created_at: new Date().toISOString(),
    league: { id: '1', name: 'Premier League', country: 'England', logo_url: null, api_id: 39, is_active: true },
  },
  {
    id: '2',
    league_id: null,
    home_team: 'Bayern Munich',
    away_team: 'Dortmund',
    match_date: new Date().toISOString(),
    tip_type: 'over_under',
    prediction: 'Over 2.5',
    odds: 1.65,
    confidence: 82,
    result: 'won',
    is_vip: false,
    vip_tier: null,
    ai_reasoning: null,
    home_score: 3,
    away_score: 1,
    status: 'finished',
    created_at: new Date().toISOString(),
    league: { id: '2', name: 'Bundesliga', country: 'Germany', logo_url: null, api_id: 78, is_active: true },
  },
  {
    id: '3',
    league_id: null,
    home_team: 'Real Madrid',
    away_team: 'Barcelona',
    match_date: new Date().toISOString(),
    tip_type: 'btts',
    prediction: 'Both Teams Score',
    odds: 1.72,
    confidence: 75,
    result: 'pending',
    is_vip: false,
    vip_tier: null,
    ai_reasoning: null,
    home_score: null,
    away_score: null,
    status: 'live',
    created_at: new Date().toISOString(),
    league: { id: '3', name: 'La Liga', country: 'Spain', logo_url: null, api_id: 140, is_active: true },
  },
  {
    id: '4',
    league_id: null,
    home_team: 'PSG',
    away_team: 'Marseille',
    match_date: new Date().toISOString(),
    tip_type: 'double_chance',
    prediction: '1X (No Away Win)',
    odds: 1.35,
    confidence: 88,
    result: 'lost',
    is_vip: false,
    vip_tier: null,
    ai_reasoning: null,
    home_score: 0,
    away_score: 1,
    status: 'finished',
    created_at: new Date().toISOString(),
    league: { id: '4', name: 'Ligue 1', country: 'France', logo_url: null, api_id: 61, is_active: true },
  },
  {
    id: '5',
    league_id: null,
    home_team: 'Inter Milan',
    away_team: 'AC Milan',
    match_date: new Date().toISOString(),
    tip_type: '1x2',
    prediction: 'Draw',
    odds: 3.20,
    confidence: 65,
    result: 'pending',
    is_vip: false,
    vip_tier: null,
    ai_reasoning: null,
    home_score: null,
    away_score: null,
    status: 'pending',
    created_at: new Date().toISOString(),
    league: { id: '5', name: 'Serie A', country: 'Italy', logo_url: null, api_id: 135, is_active: true },
  },
]

export const MOCK_VIP_TIPS: Record<VipTier, Prediction[]> = {
  odds2: [
    {
      id: 'v1', league_id: null, home_team: 'Man City', away_team: 'Liverpool',
      match_date: new Date().toISOString(), tip_type: '1x2', prediction: 'Man City Win',
      odds: 2.05, confidence: 80, result: 'pending', is_vip: true, vip_tier: 'odds2',
      ai_reasoning: 'Man City have won 8 of their last 10 home games. Liverpool missing key midfielders.',
      home_score: null, away_score: null, status: 'pending', created_at: new Date().toISOString(),
      league: { id: '1', name: 'Premier League', country: 'England', logo_url: null, api_id: 39, is_active: true },
    },
  ],
  correct_score: [
    {
      id: 'v2', league_id: null, home_team: 'Juventus', away_team: 'Roma',
      match_date: new Date().toISOString(), tip_type: 'correct_score', prediction: '2-1',
      odds: 7.50, confidence: 62, result: 'won', is_vip: true, vip_tier: 'correct_score',
      ai_reasoning: 'Juventus strong at home. Roma defense leaky away. Historical 2-1 pattern in 4 of last 6.',
      home_score: 2, away_score: 1, status: 'finished', created_at: new Date().toISOString(),
      league: { id: '5', name: 'Serie A', country: 'Italy', logo_url: null, api_id: 135, is_active: true },
    },
  ],
  ht_ft: [
    {
      id: 'v3', league_id: null, home_team: 'Atletico Madrid', away_team: 'Sevilla',
      match_date: new Date().toISOString(), tip_type: 'ht_ft', prediction: 'X/1 (Draw HT, Home Win FT)',
      odds: 5.80, confidence: 68, result: 'pending', is_vip: true, vip_tier: 'ht_ft',
      ai_reasoning: 'Atletico often start slow but dominate second halves. Strong home record.',
      home_score: null, away_score: null, status: 'pending', created_at: new Date().toISOString(),
      league: { id: '3', name: 'La Liga', country: 'Spain', logo_url: null, api_id: 140, is_active: true },
    },
  ],
  odds5: [
    {
      id: 'v4', league_id: null, home_team: 'Celtic', away_team: 'Rangers',
      match_date: new Date().toISOString(), tip_type: '1x2', prediction: 'Celtic Win',
      odds: 5.20, confidence: 72, result: 'won', is_vip: true, vip_tier: 'odds5',
      ai_reasoning: 'High-value pick. Celtic in excellent form, Rangers without 3 key players.',
      home_score: 2, away_score: 0, status: 'finished', created_at: new Date().toISOString(),
      league: { id: '6', name: 'Scottish Premiership', country: 'Scotland', logo_url: null, api_id: 179, is_active: true },
    },
  ],
  super_combo: [
    {
      id: 'v5', league_id: null, home_team: 'Ajax', away_team: 'PSV',
      match_date: new Date().toISOString(), tip_type: 'over_under', prediction: 'Over 3.5 Goals',
      odds: 2.40, confidence: 76, result: 'pending', is_vip: true, vip_tier: 'super_combo',
      ai_reasoning: 'Both teams average 3+ goals per game at home this season. Defensive weaknesses noted.',
      home_score: null, away_score: null, status: 'pending', created_at: new Date().toISOString(),
      league: { id: '7', name: 'Eredivisie', country: 'Netherlands', logo_url: null, api_id: 88, is_active: true },
    },
  ],
  over_under: [
    {
      id: 'v6', league_id: null, home_team: 'Galatasaray', away_team: 'Fenerbahce',
      match_date: new Date().toISOString(), tip_type: 'over_under', prediction: 'Over 2.5',
      odds: 1.70, confidence: 85, result: 'won', is_vip: true, vip_tier: 'over_under',
      ai_reasoning: 'Derby matches historically go over 2.5. Last 5 meetings averaged 3.8 goals.',
      home_score: 3, away_score: 2, status: 'finished', created_at: new Date().toISOString(),
      league: { id: '8', name: 'Turkish Super Lig', country: 'Turkey', logo_url: null, api_id: 203, is_active: true },
    },
  ],
  all_access: [],
}
