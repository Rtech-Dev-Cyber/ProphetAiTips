/**
 * PitchProphet – Node.js Backend Server
 *
 * Responsibilities:
 *  - Fetch daily fixtures + odds from FootyStats API
 *  - Generate AI predictions via OpenAI GPT-4
 *  - Store predictions in Supabase
 *  - Run scheduled cron jobs (daily 06:00 UTC)
 *  - REST endpoints for admin (seed predictions, update results)
 *
 * Setup:
 *  1. cp .env.example .env  and fill in all values
 *  2. npm install
 *  3. node server.js
 *
 * Or run the cron job in a background process / Render cron / Railway cron.
 */

require('dotenv').config()

const express      = require('express')
const cron         = require('node-cron')
const { createClient } = require('@supabase/supabase-js')
const OpenAI       = require('openai')
const axios        = require('axios')

const app  = express()
app.use(express.json())

// ── Clients ────────────────────────────────────────────────────────────────

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

const FOOTYSTATS_KEY = process.env.FOOTYSTATS_API_KEY
const FOOTYSTATS_BASE = 'https://api.football-data-api.com'

// ── FootyStats helpers ─────────────────────────────────────────────────────

async function fetchTodayFixtures() {
  const today = new Date().toISOString().split('T')[0]
  const res = await axios.get(`${FOOTYSTATS_BASE}/todays-matches`, {
    params: { key: FOOTYSTATS_KEY, date: today },
  })
  return res.data?.data ?? []
}

async function fetchMatchStats(matchId) {
  const res = await axios.get(`${FOOTYSTATS_BASE}/match`, {
    params: { key: FOOTYSTATS_KEY, match_id: matchId },
  })
  return res.data?.data ?? null
}

// ── OpenAI prediction generator ────────────────────────────────────────────

async function generatePrediction(matchData) {
  const prompt = `You are a professional football analyst AI.

Match: ${matchData.home_name} vs ${matchData.away_name}
Competition: ${matchData.competition_name}
Date: ${matchData.date_unix ? new Date(matchData.date_unix * 1000).toISOString() : 'Unknown'}

Home stats (this season):
- Form (last 5): ${matchData.homeStats?.formRun_overall ?? 'N/A'}
- Goals scored avg: ${matchData.homeStats?.seasonGoals_overall ?? 'N/A'}
- Clean sheets: ${matchData.homeStats?.seasonCS_overall ?? 'N/A'}

Away stats (this season):
- Form (last 5): ${matchData.awayStats?.formRun_overall ?? 'N/A'}
- Goals scored avg: ${matchData.awayStats?.seasonGoals_overall ?? 'N/A'}
- Clean sheets: ${matchData.awayStats?.seasonCS_overall ?? 'N/A'}

Provide a JSON response with:
{
  "tip_type": "1x2" | "over_under" | "btts" | "double_chance",
  "prediction": "exact prediction string e.g. 'Home Win' or 'Over 2.5 Goals' or 'Both Teams to Score'",
  "confidence": 60-95,
  "odds": 1.3-4.0,
  "reasoning": "2-3 sentences of clear reasoning"
}
Only respond with valid JSON, no markdown.`

  const completion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.3,
    max_tokens: 300,
  })

  return JSON.parse(completion.choices[0].message.content)
}

// ── Main daily prediction job ──────────────────────────────────────────────

async function runDailyPredictions() {
  console.log('[PitchProphet] Running daily prediction job...')

  try {
    const fixtures = await fetchTodayFixtures()
    console.log(`[PitchProphet] Found ${fixtures.length} fixtures today`)

    // Only process top-tier leagues
    const TOP_LEAGUE_IDS = [2, 3, 39, 61, 78, 88, 135, 140, 179, 203]
    const filtered = fixtures.filter((f) =>
      TOP_LEAGUE_IDS.includes(f.competition_id)
    )

    for (const fixture of filtered.slice(0, 20)) {
      try {
        // Check if prediction already exists
        const { data: existing } = await supabase
          .from('predictions')
          .select('id')
          .eq('home_team', fixture.home_name)
          .eq('away_team', fixture.away_name)
          .gte('match_date', new Date().toISOString().split('T')[0])
          .single()

        if (existing) {
          console.log(`[PitchProphet] Skipping duplicate: ${fixture.home_name} vs ${fixture.away_name}`)
          continue
        }

        // Get detailed stats
        const stats = await fetchMatchStats(fixture.id)

        const ai = await generatePrediction({
          ...fixture,
          homeStats: stats?.homeStats,
          awayStats: stats?.awayStats,
        })

        // Find league in DB
        const { data: league } = await supabase
          .from('leagues')
          .select('id')
          .eq('api_id', fixture.competition_id)
          .single()

        await supabase.from('predictions').insert({
          league_id: league?.id ?? null,
          home_team: fixture.home_name,
          away_team: fixture.away_name,
          match_date: new Date(fixture.date_unix * 1000).toISOString(),
          tip_type: ai.tip_type,
          prediction: ai.prediction,
          odds: ai.odds,
          confidence: ai.confidence,
          ai_reasoning: ai.reasoning,
          is_vip: false,
          status: 'pending',
          result: 'pending',
        })

        console.log(`[PitchProphet] Created prediction: ${fixture.home_name} vs ${fixture.away_name} → ${ai.prediction}`)

        // Small delay to avoid rate limits
        await new Promise((r) => setTimeout(r, 600))
      } catch (matchErr) {
        console.error(`[PitchProphet] Error for match ${fixture.id}:`, matchErr.message)
      }
    }

    console.log('[PitchProphet] Daily prediction job complete.')
  } catch (err) {
    console.error('[PitchProphet] Job failed:', err.message)
  }
}

// ── Result updater job ────────────────────────────────────────────────────

async function updateResults() {
  console.log('[PitchProphet] Updating match results...')

  const { data: pending } = await supabase
    .from('predictions')
    .select('*')
    .eq('status', 'pending')
    .lt('match_date', new Date().toISOString())

  if (!pending || pending.length === 0) {
    console.log('[PitchProphet] No pending predictions to update.')
    return
  }

  for (const pred of pending) {
    try {
      const res = await axios.get(`${FOOTYSTATS_BASE}/todays-matches`, {
        params: {
          key: FOOTYSTATS_KEY,
          date: new Date(pred.match_date).toISOString().split('T')[0],
        },
      })

      const fixtures = res.data?.data ?? []
      const match = fixtures.find(
        (f) =>
          f.home_name === pred.home_team &&
          f.away_name === pred.away_team &&
          f.status === 'complete'
      )

      if (!match) continue

      const homeGoals = match.homeGoalCount
      const awayGoals = match.awayGoalCount
      const totalGoals = homeGoals + awayGoals

      let result = 'lost'
      switch (pred.tip_type) {
        case '1x2':
          if (pred.prediction.toLowerCase().includes('home') && homeGoals > awayGoals) result = 'won'
          else if (pred.prediction.toLowerCase().includes('away') && awayGoals > homeGoals) result = 'won'
          else if (pred.prediction.toLowerCase().includes('draw') && homeGoals === awayGoals) result = 'won'
          break
        case 'over_under':
          if (pred.prediction.includes('Over') && totalGoals > 2.5) result = 'won'
          else if (pred.prediction.includes('Under') && totalGoals < 2.5) result = 'won'
          break
        case 'btts':
          if (homeGoals > 0 && awayGoals > 0) result = 'won'
          break
        case 'double_chance':
          if (pred.prediction.includes('1X') && homeGoals >= awayGoals) result = 'won'
          else if (pred.prediction.includes('X2') && awayGoals >= homeGoals) result = 'won'
          else if (pred.prediction.includes('12') && homeGoals !== awayGoals) result = 'won'
          break
      }

      await supabase.from('predictions').update({
        status: 'finished',
        result,
        home_score: homeGoals,
        away_score: awayGoals,
      }).eq('id', pred.id)

      console.log(`[PitchProphet] Updated ${pred.home_team} vs ${pred.away_team}: ${result}`)
    } catch (err) {
      console.error(`[PitchProphet] Result update error for ${pred.id}:`, err.message)
    }
  }
}

// ── Schedule cron jobs ─────────────────────────────────────────────────────

// 06:00 UTC daily — generate predictions
cron.schedule('0 6 * * *', runDailyPredictions, { timezone: 'UTC' })

// 23:00 UTC daily — update results
cron.schedule('0 23 * * *', updateResults, { timezone: 'UTC' })

// ── REST endpoints (admin / manual trigger) ────────────────────────────────

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() })
})

// Manually trigger predictions
app.post('/admin/run-predictions', async (req, res) => {
  const adminKey = req.headers['x-admin-key']
  if (adminKey !== process.env.ADMIN_SECRET_KEY) {
    return res.status(401).json({ error: 'Unauthorized' })
  }
  runDailyPredictions().catch(console.error)
  res.json({ message: 'Daily prediction job started in background.' })
})

// Manually trigger results update
app.post('/admin/update-results', async (req, res) => {
  const adminKey = req.headers['x-admin-key']
  if (adminKey !== process.env.ADMIN_SECRET_KEY) {
    return res.status(401).json({ error: 'Unauthorized' })
  }
  updateResults().catch(console.error)
  res.json({ message: 'Result update job started in background.' })
})

// Ask AI endpoint (proxy — used by the Flutter app)
app.post('/ai/ask', async (req, res) => {
  const { question, userId } = req.body
  if (!question) {
    return res.status(400).json({ error: 'question is required' })
  }

  // Deduct a credit (via service role)
  const { data: profile } = await supabase
    .from('profiles')
    .select('ai_credits')
    .eq('id', userId)
    .single()

  if (!profile || profile.ai_credits <= 0) {
    return res.status(402).json({ error: 'Insufficient AI credits' })
  }

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a professional football analysis AI. Provide concise, insightful analysis based on statistics and recent form. Keep responses under 150 words.',
        },
        { role: 'user', content: question },
      ],
      temperature: 0.5,
      max_tokens: 250,
    })

    const answer = completion.choices[0].message.content

    // Deduct credit
    await supabase.from('profiles').update({ ai_credits: profile.ai_credits - 1 }).eq('id', userId)
    await supabase.from('ai_credits_log').insert({ user_id: userId, amount: -1, reason: 'AI ask query' })

    res.json({ answer, creditsRemaining: profile.ai_credits - 1 })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── Start server ───────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`[PitchProphet] Backend running on port ${PORT}`)
  console.log('[PitchProphet] Cron jobs scheduled: predictions @ 06:00 UTC, results @ 23:00 UTC')
})
